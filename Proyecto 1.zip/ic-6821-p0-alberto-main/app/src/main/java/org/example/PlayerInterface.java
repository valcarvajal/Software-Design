package org.example;

public interface PlayerInterface {
    void makeMove(TicTacToeBoardInterface board, TicTacToeBoardInterface.Token playerSymbol);
}
