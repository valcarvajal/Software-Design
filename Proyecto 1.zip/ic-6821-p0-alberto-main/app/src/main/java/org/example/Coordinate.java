package org.example;

public record Coordinate(int row, int column) {

}
