CREATE TABLE risk_evaluations (
    id INT IDENTITY PRIMARY KEY,
    proposal_id INT NOT NULL,
    ccf_risk NUMERIC(15, 2) NOT NULL,
    pmf_risk NUMERIC(15, 2) NOT NULL,
    final_risk NUMERIC(15, 2) NOT NULL,
    ext_id VARCHAR(36) UNIQUE NOT NULL,
    created_on TIMESTAMP DEFAULT NOW,
    last_updated_on TIMESTAMP DEFAULT NOW
);