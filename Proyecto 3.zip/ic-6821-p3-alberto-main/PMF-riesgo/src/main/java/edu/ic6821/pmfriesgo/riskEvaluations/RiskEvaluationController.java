package edu.ic6821.pmfriesgo.riskEvaluations;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.math.BigDecimal;
import java.util.Optional;

@RestController
@RequestMapping("/api/risk-evaluation")
public class RiskEvaluationController {

    private static final Logger logger = LoggerFactory.getLogger(RiskEvaluationController.class);
    private static final String CREATE_RISK_EVALUATION_SUMMARY = "Create new risk evaluation";
    private static final String BEARER_AUTHENTICATION = "Bearer Authentication";
    private static final String CREATE_LOG_FORMAT = "[%s.create] Creating new risk evaluation for proposal %s";
    private static final String UNEXPECTED_ERROR_LOG_FORMAT = "[%s.create] Unexpected error %s: %s";

    @Autowired
    private RiskEvaluationService riskEvaluationService;

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    @Operation(summary = CREATE_RISK_EVALUATION_SUMMARY)
    @SecurityRequirement(name = BEARER_AUTHENTICATION)
    public RiskEvaluationDTO create(@RequestBody Proposal proposal,
                                    @RequestParam BigDecimal ccfRisk,
                                    @RequestParam BigDecimal pmfRisk) {
        logger.info(String.format(CREATE_LOG_FORMAT, this.getClass(), proposal.getExtId()));

        try {
            Optional<RiskEvaluation> optRiskEvaluation = riskEvaluationService.create(proposal, ccfRisk, pmfRisk);
            if (optRiskEvaluation.isEmpty()) {
                throw new ResponseStatusException(HttpStatus.NOT_FOUND);
            }

            RiskEvaluation riskEvaluation = optRiskEvaluation.get();
            return new RiskEvaluationDTO(riskEvaluation.getCcfRisk(), riskEvaluation.getPmfRisk(), riskEvaluation.getFinalRisk(), proposal.getExtId());
        } catch (Exception e) {
            logger.error(String.format(UNEXPECTED_ERROR_LOG_FORMAT, this.getClass(), e.getClass(), e.getMessage()), e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage(), e);
        }
    }
}