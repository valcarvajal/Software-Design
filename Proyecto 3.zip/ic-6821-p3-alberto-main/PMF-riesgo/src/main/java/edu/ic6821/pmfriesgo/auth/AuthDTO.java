package edu.ic6821.pmfriesgo.auth;

public record AuthDTO(AuthStatus status, String token) {
}
