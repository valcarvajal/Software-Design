package edu.ic6821.pmfriesgo.auth;

public enum AuthStatus {
    AUTH_SUCCEEDED, AUTH_FAILED
}
