package edu.ic6821.pmfriesgo.riskEvaluations;

import java.math.BigDecimal;

public record RiskEvaluationDTO(BigDecimal ccfRisk, BigDecimal pmfRisk, BigDecimal finalRisk, String proposalId) {
}
