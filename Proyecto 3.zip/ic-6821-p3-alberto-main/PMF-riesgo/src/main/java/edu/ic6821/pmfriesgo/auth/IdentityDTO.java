package edu.ic6821.pmfriesgo.auth;

public record IdentityDTO(String username) {
}
