package edu.ic6821.pmfriesgo.riskEvaluations;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.Optional;
import java.util.List;

@Repository
public interface RiskEvaluationRepository extends JpaRepository<RiskEvaluation, Long> {
    Optional<RiskEvaluation> findByExtId(String extId);
    List<RiskEvaluation> findByPmfRiskGreaterThanEqual(BigDecimal pmfRisk);
}
