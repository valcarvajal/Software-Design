package edu.ic6821.pmfriesgo.riskEvaluations;

import java.math.BigDecimal;

public record ProposalDTO(BigDecimal requestedAmount, String description, int installments, String status, String extId) {
}
