package edu.ic6821.pmfriesgo.auth;

public record CredentialsDTO(String username, String password) {
}
