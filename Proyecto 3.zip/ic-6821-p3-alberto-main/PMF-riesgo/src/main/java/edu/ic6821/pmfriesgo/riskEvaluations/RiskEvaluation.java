package edu.ic6821.pmfriesgo.riskEvaluations;

import edu.ic6821.pmfriesgo.framework.model.BaseEntity;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.persistence.Column;
import jakarta.persistence.OneToOne;
import jakarta.persistence.JoinColumn;
import java.math.BigDecimal;
import java.util.Objects;

@Entity
@Table(name = "risk_evaluations")
public class RiskEvaluation extends BaseEntity {

    @OneToOne
    @JoinColumn(name = "proposal_id", nullable = false)
    private Proposal proposal;

    @Column(nullable = false)
    private BigDecimal ccfRisk;

    @Column(nullable = false)
    private BigDecimal pmfRisk;

    @Column(nullable = false)
    private BigDecimal finalRisk;

    public RiskEvaluation() {
    }

    public RiskEvaluation(Proposal proposal, BigDecimal ccfRisk, BigDecimal pmfRisk, BigDecimal finalRisk) {
        this.proposal = proposal;
        this.ccfRisk = ccfRisk;
        this.pmfRisk = pmfRisk;
        this.finalRisk = finalRisk;
    }

    public Proposal getProposal() {
        return proposal;
    }

    public void setProposal(Proposal proposal) {
        this.proposal = proposal;
    }

    public BigDecimal getCcfRisk() {
        return ccfRisk;
    }

    public void setCcfRisk(BigDecimal ccfRisk) {
        this.ccfRisk = ccfRisk;
    }

    public BigDecimal getPmfRisk() {
        return pmfRisk;
    }

    public void setPmfRisk(BigDecimal pmfRisk) {
        this.pmfRisk = pmfRisk;
    }

    public BigDecimal getFinalRisk() {
        return finalRisk;
    }

    public void setFinalRisk(BigDecimal finalRisk) {
        this.finalRisk = finalRisk;
    }

    @Override
    public String toString() {
        return "RiskEvaluation{" +
                "proposal=" + proposal +
                ", ccfRisk=" + ccfRisk +
                ", pmfRisk=" + pmfRisk +
                ", finalRisk=" + finalRisk +
                '}';
    }
}
