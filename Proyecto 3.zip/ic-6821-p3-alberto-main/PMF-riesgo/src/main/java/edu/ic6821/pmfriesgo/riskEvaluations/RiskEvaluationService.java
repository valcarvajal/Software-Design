package edu.ic6821.pmfriesgo.riskEvaluations;

import edu.ic6821.pmfriesgo.riskEvaluations.ProposalDTO;
import java.math.BigDecimal;
import java.util.Optional;

public interface RiskEvaluationService {
    Optional<RiskEvaluation> create(Proposal proposal, BigDecimal ccfRisk, BigDecimal pmfRisk);
}
