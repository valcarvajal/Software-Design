package edu.ic6821.pmfriesgo.riskEvaluations;

import edu.ic6821.pmfriesgo.riskEvaluations.ProposalDTO;
import org.springframework.stereotype.Service;
import java.math.BigDecimal;
import java.util.Optional;

@Service
public class RiskEvaluationServiceImpl implements RiskEvaluationService {
    private final RiskEvaluationRepository riskEvaluationRepository;

    public RiskEvaluationServiceImpl(RiskEvaluationRepository riskEvaluationRepository) {
        this.riskEvaluationRepository = riskEvaluationRepository;
    }

    @Override
    public Optional<RiskEvaluation> create(Proposal proposal, BigDecimal ccfRisk, BigDecimal pmfRisk) {
        if (proposal == null) {
            return Optional.empty();
        }
        BigDecimal finalRisk = calculateFinalRisk(ccfRisk, pmfRisk);
        RiskEvaluation riskEvaluation = new RiskEvaluation(proposal, ccfRisk, pmfRisk, finalRisk);

        riskEvaluationRepository.save(riskEvaluation);
        return Optional.of(riskEvaluation);
    }


    private BigDecimal calculateFinalRisk(BigDecimal ccfRisk, BigDecimal pmfRisk) {
        BigDecimal ccfWeight = new BigDecimal("0.65");
        BigDecimal pmfWeight = new BigDecimal("0.35");
        return ccfRisk.multiply(ccfWeight).add(pmfRisk.multiply(pmfWeight));
    }
}
