package edu.ic6821.pmfriesgo.riskEvaluations;

import edu.ic6821.pmfriesgo.riskEvaluations.Proposal;
import edu.ic6821.pmfriesgo.riskEvaluations.RiskEvaluation;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

import java.math.BigDecimal;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@SpringBootTest
public class RiskEvaluationServiceImplTest {

    @InjectMocks
    private RiskEvaluationServiceImpl riskEvaluationService;

    @Mock
    private RiskEvaluationRepository riskEvaluationRepository;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testCreate_InvalidProposal_ShouldReturnEmpty() {
        // given
        Proposal proposal = null;
        BigDecimal ccfRisk = new BigDecimal("0.7");
        BigDecimal pmfRisk = new BigDecimal("0.5");

        // when
        Optional<RiskEvaluation> actual = riskEvaluationService.create(proposal, ccfRisk, pmfRisk);

        // then
        assertTrue(actual.isEmpty());
        verify(riskEvaluationRepository, never()).save(any(RiskEvaluation.class));
    }
}
