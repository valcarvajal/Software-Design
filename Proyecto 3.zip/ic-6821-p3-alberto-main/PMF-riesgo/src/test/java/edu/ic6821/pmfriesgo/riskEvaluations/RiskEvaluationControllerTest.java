package edu.ic6821.pmfriesgo.riskEvaluations;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.math.BigDecimal;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
class RiskEvaluationControllerTest {

    @Mock
    private RiskEvaluationService riskEvaluationService;

    @InjectMocks
    private RiskEvaluationController riskEvaluationController;

    private MockMvc mockMvc;
    private ObjectMapper objectMapper = new ObjectMapper();

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(riskEvaluationController).build();
    }

    @Test
    void testCreateRiskEvaluation_Success() throws Exception {
        // given
        Proposal proposal = new Proposal();
        proposal.setExtId("proposal123");
        BigDecimal ccfRisk = new BigDecimal("0.5");
        BigDecimal pmfRisk = new BigDecimal("0.3");

        RiskEvaluation riskEvaluation = new RiskEvaluation();
        riskEvaluation.setCcfRisk(ccfRisk);
        riskEvaluation.setPmfRisk(pmfRisk);
        riskEvaluation.setFinalRisk(ccfRisk.add(pmfRisk));

        when(riskEvaluationService.create(any(Proposal.class), any(BigDecimal.class), any(BigDecimal.class)))
                .thenReturn(Optional.of(riskEvaluation));

        // when & then
        mockMvc.perform(post("/api/risk-evaluation")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(proposal))
                        .param("ccfRisk", ccfRisk.toPlainString())
                        .param("pmfRisk", pmfRisk.toPlainString()))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.ccfRisk").value(ccfRisk.toPlainString()))
                .andExpect(jsonPath("$.pmfRisk").value(pmfRisk.toPlainString()))
                .andExpect(jsonPath("$.finalRisk").value(ccfRisk.add(pmfRisk).toPlainString()));
    }

    @Test
    void testCreateRiskEvaluation_InternalServerError() throws Exception {
        // given
        Proposal proposal = new Proposal();
        proposal.setExtId("proposal123");
        BigDecimal ccfRisk = new BigDecimal("0.5");
        BigDecimal pmfRisk = new BigDecimal("0.3");

        when(riskEvaluationService.create(any(Proposal.class), any(BigDecimal.class), any(BigDecimal.class)))
                .thenThrow(new RuntimeException("Database connection error"));

        // when & then
        mockMvc.perform(post("/api/risk-evaluation")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(proposal))
                        .param("ccfRisk", ccfRisk.toPlainString())
                        .param("pmfRisk", pmfRisk.toPlainString()))
                .andExpect(status().isInternalServerError());
    }
}
