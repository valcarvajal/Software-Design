package edu.ic6821.banca.payment;

import edu.ic6821.banca.accounts.AccountRepository;
import edu.ic6821.banca.users.UserRepository;
import edu.ic6821.banca.users.model.User;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.web.server.ResponseStatusException;

import java.math.BigDecimal;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

class PaymentControllerTest {

    @Mock
    private PaymentGatewayService paymentService;

    @Mock
    private UserRepository userRepository;

    @InjectMocks
    private PaymentController paymentController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testDepositSuccess_SINPE() {
        String firstIdentifier = "12345678"; // Número de teléfono
        String secondIdentifier = "87654321"; // Número de teléfono
        BigDecimal amount = new BigDecimal("100.0");
        PaymentMethod paymentMethod = PaymentMethod.SINPE;
        String username = "fromUser";

        User fromUser = new User("fromUser", "hashedPassword", "From User", "fromuser@example.com", "12345678");

        when(userRepository.findByPhoneNumber(firstIdentifier)).thenReturn(Optional.of(fromUser));
        when(paymentService.processDeposit(firstIdentifier, secondIdentifier, amount, paymentMethod)).thenReturn(true);

        paymentController.deposit(firstIdentifier, secondIdentifier, amount, paymentMethod, username);

        verify(paymentService, times(1)).processDeposit(firstIdentifier, secondIdentifier, amount, paymentMethod);
    }

    @Test
    void testDepositUserMismatch() {
        String firstIdentifier = "12345678";
        String secondIdentifier = "87654321";
        BigDecimal amount = new BigDecimal("100.0");
        PaymentMethod paymentMethod = PaymentMethod.SINPE;
        String username = "unauthorizedUser";

        User fromUser = new User("fromUser", "hashedPassword", "From User", "fromuser@example.com", "12345678");

        when(userRepository.findByPhoneNumber(firstIdentifier)).thenReturn(Optional.of(fromUser));

        assertThrows(ResponseStatusException.class, () ->
                paymentController.deposit(firstIdentifier, secondIdentifier, amount, paymentMethod, username));
    }

    @Test
    void testDepositInsufficientFunds() {
        String firstIdentifier = "12345678";
        String secondIdentifier = "87654321";
        BigDecimal amount = new BigDecimal("500.0");
        PaymentMethod paymentMethod = PaymentMethod.SINPE;
        String username = "fromUser";

        when(paymentService.processDeposit(firstIdentifier, secondIdentifier, amount, paymentMethod)).thenReturn(false);

        assertThrows(ResponseStatusException.class, () ->
                paymentController.deposit(firstIdentifier, secondIdentifier, amount, paymentMethod, username));
    }
}
