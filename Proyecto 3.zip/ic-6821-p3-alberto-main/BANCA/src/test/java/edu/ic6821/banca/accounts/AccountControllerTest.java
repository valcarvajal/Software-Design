package edu.ic6821.banca.accounts;

import edu.ic6821.banca.accounts.model.Account;
import edu.ic6821.banca.users.UserRepository;
import edu.ic6821.banca.users.model.User;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class AccountControllerTest {

    @Mock
    private AccountService accountService;

    @InjectMocks
    private AccountController accountController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Mock
    private AccountRepository accountRepository;

    @Mock
    private UserRepository userRepository;

    @Test
    void testTransferAccountNotFound() {
        String fromIban = "IBAN1";
        String toIban = "IBAN2";
        BigDecimal amount = new BigDecimal("100.0");
        String username = "testUser";

        when(accountRepository.findByIBAN(fromIban)).thenReturn(Optional.empty());

        ResponseStatusException exception = assertThrows(ResponseStatusException.class, () ->
                accountController.transfer(fromIban, toIban, amount, username));

        assertEquals("La cuenta no existe", exception.getReason());
        verify(accountService, never()).transfer(anyString(), anyString(), any(BigDecimal.class));
    }

    @Test
    void testTransferUnauthorizedUser() {
        String fromIban = "IBAN1";
        String toIban = "IBAN2";
        BigDecimal amount = new BigDecimal("100.0");
        String username = "unauthorizedUser";

        Account fromAccount = new Account(fromIban, new BigDecimal("200.0"), "DOLAR", 1L);
        User accountOwner = new User("authorizedUser", "password", "Name", "email@example.com", "12345678");

        when(accountRepository.findByIBAN(fromIban)).thenReturn(Optional.of(fromAccount));
        when(userRepository.findById(fromAccount.getUserId())).thenReturn(Optional.of(accountOwner));

        ResponseStatusException exception = assertThrows(ResponseStatusException.class, () ->
                accountController.transfer(fromIban, toIban, amount, username));

        assertEquals("El usuario no tiene permiso para transferir desde esta cuenta", exception.getReason());
        verify(accountService, never()).transfer(anyString(), anyString(), any(BigDecimal.class));
    }

    @Test
    void testTransferInsufficientFunds() {
        String fromIban = "IBAN1";
        String toIban = "IBAN2";
        BigDecimal amount = new BigDecimal("300.0");
        String username = "authorizedUser";

        Account fromAccount = new Account(fromIban, new BigDecimal("200.0"), "DOLAR", 1L);
        User accountOwner = new User(username, "password", "Name", "email@example.com", "12345678");

        when(accountRepository.findByIBAN(fromIban)).thenReturn(Optional.of(fromAccount));
        when(userRepository.findById(fromAccount.getUserId())).thenReturn(Optional.of(accountOwner));
        when(accountService.transfer(fromIban, toIban, amount)).thenReturn(false);

        ResponseStatusException exception = assertThrows(ResponseStatusException.class, () ->
                accountController.transfer(fromIban, toIban, amount, username));

        assertEquals("Transfer failed due to insufficient funds or invalid IBAN.", exception.getReason());
        verify(accountService, times(1)).transfer(fromIban, toIban, amount);
    }

    @Test
    void testWithdrawAccountNotFound() {
        String iban = "IBAN1";
        BigDecimal amount = new BigDecimal("50.0");
        String username = "testUser";

        when(accountRepository.findByIBAN(iban)).thenReturn(Optional.empty());

        ResponseStatusException exception = assertThrows(ResponseStatusException.class, () ->
                accountController.withdraw(iban, amount, username));

        assertEquals("La cuenta no existe", exception.getReason());
        verify(accountService, never()).withdraw(anyString(), any(BigDecimal.class));
    }

    @Test
    void testWithdrawUnauthorizedUser() {
        String iban = "IBAN1";
        BigDecimal amount = new BigDecimal("50.0");
        String username = "unauthorizedUser";

        Account account = new Account(iban, new BigDecimal("200.0"), "DOLAR", 1L);
        User accountOwner = new User("authorizedUser", "password", "Name", "email@example.com", "12345678");

        when(accountRepository.findByIBAN(iban)).thenReturn(Optional.of(account));
        when(userRepository.findById(account.getUserId())).thenReturn(Optional.of(accountOwner));

        ResponseStatusException exception = assertThrows(ResponseStatusException.class, () ->
                accountController.withdraw(iban, amount, username));

        assertEquals("El usuario no tiene permiso para transferir desde esta cuenta", exception.getReason());
        verify(accountService, never()).withdraw(anyString(), any(BigDecimal.class));
    }

    @Test
    void testTransferUnexpectedError() {
        String fromIban = "IBAN1";
        String toIban = "IBAN2";
        BigDecimal amount = new BigDecimal("100.0");
        String username = "authorizedUser";

        Account fromAccount = new Account(fromIban, new BigDecimal("200.0"), "DOLAR", 1L);
        User accountOwner = new User(username, "password", "Name", "email@example.com", "12345678");

        when(accountRepository.findByIBAN(fromIban)).thenReturn(Optional.of(fromAccount));
        when(userRepository.findById(fromAccount.getUserId())).thenReturn(Optional.of(accountOwner));
        when(accountService.transfer(fromIban, toIban, amount)).thenThrow(new RuntimeException("Unexpected error"));

        ResponseStatusException exception = assertThrows(ResponseStatusException.class, () ->
                accountController.transfer(fromIban, toIban, amount, username));

        assertEquals("Transfer failed due to insufficient funds or invalid IBAN.", exception.getReason());
        verify(accountService, times(1)).transfer(fromIban, toIban, amount);
    }

    @Test
    void testWithdrawUnexpectedError() {
        String iban = "IBAN1";
        BigDecimal amount = new BigDecimal("50.0");
        String username = "authorizedUser";

        Account account = new Account(iban, new BigDecimal("200.0"), "DOLAR", 1L);
        User accountOwner = new User(username, "password", "Name", "email@example.com", "12345678");

        when(accountRepository.findByIBAN(iban)).thenReturn(Optional.of(account));
        when(userRepository.findById(account.getUserId())).thenReturn(Optional.of(accountOwner));
        when(accountService.withdraw(iban, amount)).thenThrow(new RuntimeException("Unexpected error"));

        ResponseStatusException exception = assertThrows(ResponseStatusException.class, () ->
                accountController.withdraw(iban, amount, username));

        assertEquals("Withdrawal failed due to insufficient funds or invalid IBAN.", exception.getReason());
        verify(accountService, times(1)).withdraw(iban, amount);
    }

    @Test
    void testGetTransactionReportAccountNotFound() {
        String accountExtId = "invalid-ext-id";
        LocalDate startDate = LocalDate.of(2024, 10, 10);
        LocalDate endDate = LocalDate.of(2024, 10, 20);
        String username = "testUser";

        when(accountRepository.findByExtId(accountExtId)).thenReturn(Optional.empty());

        ResponseStatusException exception = assertThrows(ResponseStatusException.class, () ->
                accountController.getTransactionReport(accountExtId, startDate, endDate, username));

        assertEquals("Account not found or does not belong to the authenticated user with username: " + username, exception.getReason());
        verify(accountService, never()).getTransactionReport(anyLong(), any(), any());
    }

    @Test
    void testGetTransactionReportUnauthorizedUser() {
        String accountExtId = "valid-ext-id";
        LocalDate startDate = LocalDate.of(2024, 10, 10);
        LocalDate endDate = LocalDate.of(2024, 10, 20);
        String username = "unauthorizedUser";

        Account account = new Account();
        account.setUserId(1L);
        User accountOwner = new User("authorizedUser", "password", "Name", "email@example.com", "12345678");

        when(accountRepository.findByExtId(accountExtId)).thenReturn(Optional.of(account));
        when(userRepository.findById(account.getUserId())).thenReturn(Optional.of(accountOwner));

        ResponseStatusException exception = assertThrows(ResponseStatusException.class, () ->
                accountController.getTransactionReport(accountExtId, startDate, endDate, username));

        assertEquals("El usuario no tiene permiso para transferir desde esta cuenta", exception.getReason());
        verify(accountService, never()).getTransactionReport(anyLong(), any(), any());
    }

    @Test
    void testGetTransactionReportUserNotFound() {
        String accountExtId = "valid-ext-id";
        LocalDate startDate = LocalDate.of(2024, 10, 10);
        LocalDate endDate = LocalDate.of(2024, 10, 20);
        String username = "testUser";

        Account account = new Account();
        account.setUserId(1L);

        when(accountRepository.findByExtId(accountExtId)).thenReturn(Optional.of(account));
        when(userRepository.findById(account.getUserId())).thenReturn(Optional.empty());

        ResponseStatusException exception = assertThrows(ResponseStatusException.class, () ->
                accountController.getTransactionReport(accountExtId, startDate, endDate, username));

        assertEquals("El propietario de la cuenta no existe", exception.getReason());
        verify(accountService, never()).getTransactionReport(anyLong(), any(), any());
    }

    @Test
    void testGetTransactionReportUnexpectedError() {
        String accountExtId = "valid-ext-id";
        LocalDate startDate = LocalDate.of(2024, 10, 10);
        LocalDate endDate = LocalDate.of(2024, 10, 20);
        String username = "testUser";

        Account account = new Account();
        account.setId(1L);
        account.setUserId(1L);
        User accountOwner = new User(username, "password", "Name", "email@example.com", "12345678");

        when(accountRepository.findByExtId(accountExtId)).thenReturn(Optional.of(account));
        when(userRepository.findById(account.getUserId())).thenReturn(Optional.of(accountOwner));
        when(accountService.getTransactionReport(anyLong(), any(), any())).thenThrow(new RuntimeException("Unexpected error"));

        ResponseStatusException exception = assertThrows(ResponseStatusException.class, () ->
                accountController.getTransactionReport(accountExtId, startDate, endDate, username));

        assertEquals("Failed to fetch transactions for account.", exception.getReason());
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, exception.getStatusCode());

        verify(accountService, times(1)).getTransactionReport(account.getId(), startDate.atStartOfDay(), endDate.atTime(23, 59, 59));
    }



}
