package edu.ic6821.banca.users;

import edu.ic6821.banca.users.model.User;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.util.Optional;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
public class UserRepositoryIntegrationTest {

    @Autowired
    private UserRepository userRepository;

    @Test
    public void findByExtId() {
        // given
        final String uniqueExtId = UUID.randomUUID().toString();
        final User user1 = new User(
                "username|" + UUID.randomUUID(),
                "password1",
                "name1",
                "email1@" + UUID.randomUUID() + ".com",
                "phone123"
        );
        user1.setExtId(uniqueExtId);

        final User savedUser1 = userRepository.save(user1);

        // when
        final Optional<User> actual = userRepository.findByExtId(uniqueExtId);

        // then
        assertThat(actual).isNotEmpty();
        assertThat(actual.get().getExtId()).isEqualTo(savedUser1.getExtId());
        assertThat(actual.get().getUsername()).isEqualTo(savedUser1.getUsername());
    }

    @Test
    public void findByExtIdNoResult() {
        // given
        final String nonExistingId = UUID.randomUUID().toString();

        // when
        final Optional<User> actual = userRepository.findByExtId(nonExistingId);

        // then
        assertThat(actual).isEmpty();
    }

    @Test
    public void findByEmail() {
        // given
        final User user1 = new User(
                "username|" + UUID.randomUUID(),
                "password1",
                "name1",
                "email1",
                "phone1"
        );
        final User savedUser1 = userRepository.save(user1);

        final Optional<User> potentialRetrievedUser = userRepository.findById(savedUser1.getId());
        assertThat(potentialRetrievedUser).isPresent();
        final User retrievedUser = potentialRetrievedUser.get();

        // when
        final Optional<User> actual = userRepository.findByEmail(retrievedUser.getEmail());

        // then
        assertThat(actual).isNotEmpty();
        assertThat(actual.get()).isEqualTo(retrievedUser);
    }

    @Test
    public void findByEmailNoResult() {
        // given
        final String nonExistingId = UUID.randomUUID().toString();

        // when
        final Optional<User> actual = userRepository.findByEmail(nonExistingId);

        // then
        assertThat(actual).isEmpty();
    }

    @Test
    public void findByUsername() {
        // given
        final String uniqueUsername = "testUsername-" + UUID.randomUUID();
        final User user1 = new User(
                uniqueUsername,
                "password1",
                "name1",
                "email2@" + UUID.randomUUID() + ".com",
                "phone1234"
        );

        final User savedUser1 = userRepository.save(user1);

        // when
        final Optional<User> actual = userRepository.findByUsername(uniqueUsername);

        // then
        assertThat(actual).isNotEmpty();
        assertThat(actual.get().getUsername()).isEqualTo(savedUser1.getUsername());
        assertThat(actual.get().getEmail()).isEqualTo(savedUser1.getEmail());
    }

    @Test
    public void findByUsernameNoResult() {
        // given
        final String nonExistingId = UUID.randomUUID().toString();

        // when
        final Optional<User> actual = userRepository.findByUsername(nonExistingId);

        // then
        assertThat(actual).isEmpty();
    }

    @Test
    public void findByPhoneNumber() {
        // given
        final String uniquePhoneNumber = "phone" + UUID.randomUUID();
        final User user1 = new User(
                "username|" + UUID.randomUUID(),
                "password1",
                "name1",
                "email3@" + UUID.randomUUID() + ".com",
                uniquePhoneNumber
        );

        final User savedUser1 = userRepository.save(user1);

        // when
        final Optional<User> actual = userRepository.findByPhoneNumber(uniquePhoneNumber);

        // then
        assertThat(actual).isNotEmpty();
        assertThat(actual.get().getPhoneNumber()).isEqualTo(savedUser1.getPhoneNumber());
        assertThat(actual.get().getUsername()).isEqualTo(savedUser1.getUsername());
    }

    @Test
    public void findByPhoneNumberNoResult() {
        // given
        final String nonExistingPhoneNumber = "phone" + UUID.randomUUID();

        // when
        final Optional<User> actual = userRepository.findByPhoneNumber(nonExistingPhoneNumber);

        // then
        assertThat(actual).isEmpty();
    }

}
