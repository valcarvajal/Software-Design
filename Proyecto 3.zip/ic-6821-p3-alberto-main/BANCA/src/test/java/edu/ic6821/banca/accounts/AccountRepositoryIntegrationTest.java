package edu.ic6821.banca.accounts;

import edu.ic6821.banca.accounts.model.Account;
import edu.ic6821.banca.users.UserRepository;
import edu.ic6821.banca.users.model.User;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.ActiveProfiles;

import java.math.BigDecimal;
import java.util.Optional;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;

@DataJpaTest
@ActiveProfiles("test")
public class AccountRepositoryIntegrationTest {

    @Autowired
    private AccountRepository accountRepository;

    @Autowired
    private UserRepository userRepository;

    @Test
    public void findByIban() {
        // given
        final Account account = new Account();
        account.setIBAN("IBAN" + UUID.randomUUID());
        account.setInitialBalance(new BigDecimal("1000.00"));
        account.setCurrencyType("DOLAR");
        account.setExtId(UUID.randomUUID().toString());
        account.setUserId(1L);

        final Account savedAccount = accountRepository.save(account);

        // when
        final Optional<Account> actual = accountRepository.findByIBAN(savedAccount.getIBAN());

        // then
        assertThat(actual).isNotEmpty();
        assertThat(actual.get()).isEqualTo(savedAccount);
    }

    @Test
    public void findByIbanNoResult() {
        // given
        final String nonExistingIban = "IBAN" + UUID.randomUUID();

        // when
        final Optional<Account> actual = accountRepository.findByIBAN(nonExistingIban);

        // then
        assertThat(actual).isEmpty();
    }

    @Test
    public void saveAccountAndVerifyProperties() {
        // given
        final Account account = new Account();
        account.setIBAN("IBAN" + UUID.randomUUID());
        account.setInitialBalance(new BigDecimal("2000.00"));
        account.setCurrencyType("DOLAR");
        account.setExtId(UUID.randomUUID().toString());
        account.setUserId(1L);

        // when
        final Account savedAccount = accountRepository.save(account);

        // then
        assertThat(savedAccount.getId()).isNotNull();
        assertThat(savedAccount.getIBAN()).isEqualTo(account.getIBAN());
        assertThat(savedAccount.getInitialBalance()).isEqualTo(new BigDecimal("2000.00"));
        assertThat(savedAccount.getCurrencyType()).isEqualTo("DOLAR");
        assertThat(savedAccount.getExtId()).isEqualTo(account.getExtId());
    }

    @Test
    public void findByExtId() {
        // given
        final Account account = new Account();
        account.setIBAN("IBAN" + UUID.randomUUID());
        account.setInitialBalance(new BigDecimal("1500.00"));
        account.setCurrencyType("DOLAR");
        account.setExtId(UUID.randomUUID().toString().substring(0, 36));
        account.setUserId(2L);

        final Account savedAccount = accountRepository.save(account);

        // when
        final Optional<Account> actual = accountRepository.findByExtId(savedAccount.getExtId());

        // then
        assertThat(actual).isNotEmpty();
        assertThat(actual.get()).isEqualTo(savedAccount);
    }

    @Test
    public void findByExtIdNoResult() {
        // given
        final String nonExistingExtId = "EXT-" + UUID.randomUUID().toString().substring(0, 36);

        // when
        final Optional<Account> actual = accountRepository.findByExtId(nonExistingExtId);

        // then
        assertThat(actual).isEmpty();
    }

    @Test
    public void findByUserId() {
        // given
        final User user = new User("testUser", "hashedPassword", "Test User", "testuser@example.com", "55555555");

        final User savedUser = userRepository.save(user);
        assertThat(savedUser).isNotNull();
        assertThat(savedUser.getId()).isNotNull();

        final Account account = new Account();
        account.setIBAN("IBAN" + UUID.randomUUID());
        account.setInitialBalance(new BigDecimal("1200.00"));
        account.setCurrencyType("DOLAR");
        account.setExtId(UUID.randomUUID().toString().substring(0, 36));
        account.setUserId(savedUser.getId());

        accountRepository.save(account);

        // when
        final Optional<Account> actual = accountRepository.findByUserId(savedUser.getId());

        // then
        assertThat(actual).isNotEmpty();
        assertThat(actual.get()).isEqualTo(account);
    }


    @Test
    public void findByUserIdNoResult() {
        // given
        final Long nonExistingUserId = 99L;

        // when
        final Optional<Account> actual = accountRepository.findByUserId(nonExistingUserId);

        // then
        assertThat(actual).isEmpty();
    }
}
