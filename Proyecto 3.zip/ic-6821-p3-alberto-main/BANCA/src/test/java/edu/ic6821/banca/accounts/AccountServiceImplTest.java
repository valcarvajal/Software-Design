package edu.ic6821.banca.accounts;

import edu.ic6821.banca.accounts.model.Account;
import edu.ic6821.banca.accounts.model.Transaction;
import edu.ic6821.banca.users.UserRepository;
import edu.ic6821.banca.users.model.User;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Optional;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class AccountServiceImplTest {

    @Mock
    private AccountRepository accountRepository;

    @Mock
    private UserRepository userRepository;

    @Mock
    private AccountServiceImpl accountService;

    @InjectMocks
    private AccountController accountController;


    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

    }

    @Test
    void testTransferSuccess() {
        String fromIban = "IBAN1";
        String toIban = "IBAN2";
        BigDecimal amount = new BigDecimal("100.0");
        String username = "fromUser";

        Long fromUserId = 1L;
        Long toUserId = 2L;
        BigDecimal initialBalance = new BigDecimal("500.00");

        User fromUser = new User("fromUser", "hashedPassword", "From User", "fromuser@example.com", "55555555");
        fromUser.setId(fromUserId);

        User toUser = new User("toUser", "hashedPassword", "To User", "touser@example.com", "55555555");
        toUser.setId(toUserId);

        Account fromAccount = new Account(fromIban, initialBalance, "DOLAR", fromUserId);
        fromAccount.setExtId("Ext-Id-From");

        Account toAccount = new Account(toIban, initialBalance, "DOLAR", toUserId);
        toAccount.setExtId("Ext-Id-To");

        when(accountRepository.findByIBAN(fromIban)).thenReturn(Optional.of(fromAccount));
        when(accountRepository.findByIBAN(toIban)).thenReturn(Optional.of(toAccount));

        when(userRepository.findById(fromUserId)).thenReturn(Optional.of(fromUser));

        when(accountService.transfer(fromIban, toIban, amount)).thenReturn(true);

        accountController.transfer(fromIban, toIban, amount, username);

        verify(accountService, times(1)).transfer(fromIban, toIban, amount);
    }

    @Test
    void testWithdrawSuccess() {
        Long userId = 1L;
        String username = "testUser";
        String iban = "IBAN0001";
        BigDecimal initialBalance = new BigDecimal("500.00");
        BigDecimal withdrawAmount = new BigDecimal("10.00");

        User user = new User(username, "hashedPassword", "Test User", "testuser@example.com", "55555555");
        user.setId(userId);

        Account account = new Account(iban, initialBalance, "DOLAR", userId);

        when(accountRepository.findByIBAN(iban)).thenReturn(Optional.of(account));
        when(userRepository.findById(userId)).thenReturn(Optional.of(user));
        when(accountService.withdraw(iban, withdrawAmount)).thenReturn(true);

        assertDoesNotThrow(() -> accountController.withdraw(iban, withdrawAmount, username));

        verify(accountService, times(1)).withdraw(iban, withdrawAmount);
    }

    @Test
    void testGetTransactionReportSuccess() {
        Long userId = 1L;
        String username = "testUser";
        String iban = "IBAN0001";
        BigDecimal initialBalance = new BigDecimal("500.00");
        LocalDate startDate = LocalDate.of(2024, 10, 10);
        LocalDate endDate = LocalDate.of(2024, 10, 20);
        LocalDateTime transactionDate = LocalDateTime.of(2024, 10, 15, 10, 0);

        User user = new User(username, "hashedPassword", "Test User", "testuser@example.com", "55555555");
        user.setId(userId);

        Account account = new Account(iban, initialBalance, "DOLAR", userId);
        account.setExtId("Ext-Id-1");

        when(userRepository.findById(userId)).thenReturn(Optional.of(user));
        when(accountRepository.findByExtId("Ext-Id-1")).thenReturn(Optional.of(account));

        Transaction transaction = new Transaction(account, TransactionType.INGRESO, new BigDecimal("100"), "Test Description");
        transaction.setTransactionDate(transactionDate);

        when(accountService.getTransactionReport(account.getId(), startDate.atStartOfDay(), endDate.atTime(23, 59, 59)))
                .thenReturn(List.of(transaction));

        List<TransactionDTO> result = accountController.getTransactionReport("Ext-Id-1", startDate, endDate, username);

        assertFalse(result.isEmpty(), "El resultado debería contener al menos una transacción");

        assertEquals(1, result.size(), "El resultado debería contener exactamente una transacción");
        assertEquals("Test Description", result.get(0).description());
        assertEquals("INGRESO", result.get(0).transactionType());
        assertEquals(new BigDecimal("100"), result.get(0).amount());

        verify(accountService, times(1)).getTransactionReport(account.getId(), startDate.atStartOfDay(), endDate.atTime(23, 59, 59));
    }
}
