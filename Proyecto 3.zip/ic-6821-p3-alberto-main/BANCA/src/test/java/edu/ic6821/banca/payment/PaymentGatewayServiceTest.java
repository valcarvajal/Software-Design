package edu.ic6821.banca.payment;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.math.BigDecimal;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.*;

class PaymentGatewayServiceTest {

    @Mock
    private SinpePaymentAdapter sinpePaymentAdapter;

    @Mock
    private CreditCardPaymentAdapter creditCardPaymentAdapter;

    @Mock
    private ManualBankDepositAdapter manualBankDepositAdapter;

    @InjectMocks
    private PaymentGatewayService paymentService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        paymentService = new PaymentGatewayService(List.of(sinpePaymentAdapter, creditCardPaymentAdapter, manualBankDepositAdapter));
    }

    @Test
    void testProcessDeposit_SINPE_Success() {
        String firstIdentifier = "12345678";
        String secondIdentifier = "87654321";
        BigDecimal amount = new BigDecimal("100.0");
        PaymentMethod paymentMethod = PaymentMethod.SINPE;

        when(sinpePaymentAdapter.deposit(firstIdentifier, secondIdentifier, amount)).thenReturn(true);

        boolean result = paymentService.processDeposit(firstIdentifier, secondIdentifier, amount, paymentMethod);

        assertTrue(result);
        verify(sinpePaymentAdapter, times(1)).deposit(firstIdentifier, secondIdentifier, amount);
    }

    @Test
    void testProcessDeposit_CreditCard_Success() {
        String firstIdentifier = "IBAN1";
        String secondIdentifier = "IBAN2";
        BigDecimal amount = new BigDecimal("200.0");
        PaymentMethod paymentMethod = PaymentMethod.CREDIT_CARD;

        when(creditCardPaymentAdapter.deposit(firstIdentifier, secondIdentifier, amount)).thenReturn(true);

        boolean result = paymentService.processDeposit(firstIdentifier, secondIdentifier, amount, paymentMethod);

        assertTrue(result);
        verify(creditCardPaymentAdapter, times(1)).deposit(firstIdentifier, secondIdentifier, amount);
    }

    @Test
    void testProcessDeposit_ManualBankDeposit_Success() {
        String firstIdentifier = "IBAN1";
        String secondIdentifier = "IBAN2";
        BigDecimal amount = new BigDecimal("300.0");
        PaymentMethod paymentMethod = PaymentMethod.MANUAL_BANK_DEPOSIT;

        when(manualBankDepositAdapter.deposit(firstIdentifier, secondIdentifier, amount)).thenReturn(true);

        boolean result = paymentService.processDeposit(firstIdentifier, secondIdentifier, amount, paymentMethod);

        assertTrue(result);
        verify(manualBankDepositAdapter, times(1)).deposit(firstIdentifier, secondIdentifier, amount);
    }
}
