CREATE TABLE accounts (
    id INT IDENTITY PRIMARY KEY,
    IBAN VARCHAR(256) UNIQUE NOT NULL,
    initial_balance NUMERIC(15, 2) NOT NULL,
    currency_type VARCHAR(256) NOT NULL,
    created_on TIMESTAMP DEFAULT NOW,
    last_updated_on TIMESTAMP DEFAULT NOW,
    user_id INT,
    ext_id VARCHAR(36) UNIQUE NOT NULL,
    FOREIGN KEY(user_id) REFERENCES users(id)
);




