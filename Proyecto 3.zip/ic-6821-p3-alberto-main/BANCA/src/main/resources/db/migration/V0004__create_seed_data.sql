INSERT INTO users (id, username, password, name, email, phone_number, ext_id, created_on, last_updated_on)
VALUES
(1, 'jp', '$2a$10$YMI2QR1U1oUjqTe.qW6ubu3evJl6R8giN2kteGEnkkAimoRkt/J3i', 'Jose Fernandez', 'jp@egmail.com', '11111111', 'ext-id-user1', NOW(), NOW()),
(2, 'beto', '$2a$10$HnwZr57eC2mb6nsfuUpD0Oef/S3jhdmDUEdNZznyWPaokff.lKdNC', 'Alberto Guerrero', 'beto@hotmail.com', '22222222', 'ext-id-user2', NOW(), NOW()),
(3, 'diego', '$2a$10$7PQ5ycOHrw1i5VY7rhacMOTzVe6pu.nHfWXPTsDFxTnTloLnvN31S', 'Diego Munguia', 'diego@example.com', '33333333', 'ext-id-user3', NOW(), NOW());

INSERT INTO accounts (id, IBAN, initial_balance, currency_type, user_id, ext_id, created_on, last_updated_on)
VALUES
(1, 'IBAN0001', 1000.00, 'DOLAR', 1, 'ext-id-account1', NOW(), NOW()),
(2, 'IBAN0002', 2000.00, 'COLON', 2, 'ext-id-account2', NOW(), NOW()),
(3, 'IBAN0003', 3000.00, 'DOLAR', 3, 'ext-id-account3', NOW(), NOW());

INSERT INTO transactions (id, ext_id, account_id, transaction_type, amount, transaction_date, created_on, last_updated_on, description)
VALUES
(1, 'ext-id-trans1', 1, 'INGRESO', 500.00, NOW(), NOW(), NOW(), 'Deposit to account 1'),
(2, 'ext-id-trans2', 2, 'EGRESO', 300.00, NOW(), NOW(), NOW(), 'Withdrawal from account 2'),
(3, 'ext-id-trans3', 3, 'INGRESO', 800.00, NOW(), NOW(), NOW(), 'Deposit to account 3');
