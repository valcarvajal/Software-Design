CREATE TABLE transactions (
    id INT IDENTITY PRIMARY KEY,
    ext_id VARCHAR(36) UNIQUE NOT NULL,
    account_id INT NOT NULL,
    transaction_type VARCHAR(10) CHECK (transaction_type IN ('INGRESO', 'EGRESO')),
    amount NUMERIC(15, 2) NOT NULL,
    transaction_date TIMESTAMP DEFAULT NOW,
    created_on TIMESTAMP DEFAULT NOW,
    last_updated_on TIMESTAMP DEFAULT NOW,
    description VARCHAR(256),
    FOREIGN KEY (account_id) REFERENCES accounts(id)
);