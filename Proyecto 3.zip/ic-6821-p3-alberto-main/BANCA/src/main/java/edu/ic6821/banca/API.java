package edu.ic6821.banca;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class API {

    public static void main(final String[] args) {
        SpringApplication.run(API.class, args);
    }

}
