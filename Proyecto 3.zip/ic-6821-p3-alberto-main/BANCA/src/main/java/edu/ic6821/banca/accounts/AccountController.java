package edu.ic6821.banca.accounts;

import edu.ic6821.banca.accounts.model.Account;
import edu.ic6821.banca.accounts.model.Transaction;
import edu.ic6821.banca.users.UserRepository;
import edu.ic6821.banca.users.model.User;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/user/{userExtId}/account")
public class AccountController implements AccountGatewayPort {

    private static final String LOG_TRANSFER = "[%s.transfer] Transferring %f from IBAN %s to IBAN %s by user %s";
    private static final String LOG_WITHDRAW = "[%s.withdraw] Withdrawing %f from IBAN %s by user %s";
    private static final String LOG_TRANSFER_FAILED = "[%s.transfer] Transfer failed: %s";
    private static final String LOG_WITHDRAW_FAILED = "[%s.withdraw] Withdrawal failed: %s";
    private static final String ERROR_TRANSFER_FAILED = "Transfer failed due to insufficient funds or invalid IBAN.";
    private static final String ERROR_WITHDRAW_FAILED = "Withdrawal failed due to insufficient funds or invalid IBAN.";
    private static final String LOG_GET_TRANSACTIONS = "[%s.getTransactionReport] Fetching transactions for account %s from %s to %s by user %s";
    private static final String LOG_GET_TRANSACTIONS_FAILED = "[%s.getTransactionReport] Failed to fetch transactions for account %s: %s";
    private static final String LOG_GET_ACCOUNT_NOT_FOUND = "Account not found or does not belong to the authenticated user with username: ";
    private static final String ERROR_TRANSACTIONS_FAILED = "Failed to fetch transactions for account.";
    private static final String DAY_MONTH_YEAR_FORMAT = "dd-MM-yyyy";
    private static final String ACCOUNT_DOES_NOT_EXIST = "La cuenta no existe";
    private static final String USER_DOES_NOT_EXIST = "El propietario de la cuenta no existe";
    private static final String UNAUTHORIZED_USER_ACCESS = "El usuario no tiene permiso para transferir desde esta cuenta";
    private static final Logger logger = LoggerFactory.getLogger(AccountController.class);

    @Autowired
    private AccountService accountService;

    @Autowired
    private AccountRepository accountRepository;

    @Autowired
    private UserRepository userRepository;

    @PostMapping("/transactions")
    @Operation(summary = "Transfer funds between accounts using source and destination IBANs")
    @SecurityRequirement(name = "Bearer Authentication")
    public void transfer(@RequestParam String fromIban, @RequestParam String toIban, @RequestParam BigDecimal amount, @RequestAttribute String username) {
        try {
            logger.info(String.format(LOG_TRANSFER, this.getClass(), amount, fromIban, toIban, username));

            Account fromAccount = accountRepository.findByIBAN(fromIban)
                    .orElseThrow(() -> new ResponseStatusException(HttpStatus.FORBIDDEN, ACCOUNT_DOES_NOT_EXIST));

            User accountOwner = userRepository.findById(fromAccount.getUserId())
                    .orElseThrow(() -> new ResponseStatusException(HttpStatus.FORBIDDEN, USER_DOES_NOT_EXIST));

            if (!accountOwner.getUsername().equals(username)) {
                throw new ResponseStatusException(HttpStatus.FORBIDDEN, UNAUTHORIZED_USER_ACCESS);
            }

            boolean success = accountService.transfer(fromIban, toIban, amount);
            if (!success) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, ERROR_TRANSFER_FAILED);
            }
        } catch (ResponseStatusException e) {
            logger.error(String.format(LOG_TRANSFER_FAILED, this.getClass(), e.getReason()), e);
            throw e;
        } catch (Exception e) {
            logger.error(String.format(LOG_TRANSFER_FAILED, this.getClass(), e.getMessage()), e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, ERROR_TRANSFER_FAILED);
        }
    }

    @PostMapping("/withdrawal")
    @Operation(summary = "Withdraw funds from account using IBAN")
    @SecurityRequirement(name = "Bearer Authentication")
    public void withdraw(@RequestParam String iban, @RequestParam BigDecimal amount, @RequestAttribute String username) {
        try {
            logger.info(String.format(LOG_WITHDRAW, this.getClass(), amount, iban, username));

            Account account = accountRepository.findByIBAN(iban)
                    .orElseThrow(() -> new ResponseStatusException(HttpStatus.FORBIDDEN, ACCOUNT_DOES_NOT_EXIST));

            User accountOwner = userRepository.findById(account.getUserId())
                    .orElseThrow(() -> new ResponseStatusException(HttpStatus.FORBIDDEN, USER_DOES_NOT_EXIST));

            if (!accountOwner.getUsername().equals(username)) {
                throw new ResponseStatusException(HttpStatus.FORBIDDEN, UNAUTHORIZED_USER_ACCESS);
            }

            boolean success = accountService.withdraw(iban, amount);
            if (!success) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, ERROR_WITHDRAW_FAILED);
            }
        } catch (ResponseStatusException e) {
            logger.error(String.format(LOG_WITHDRAW_FAILED, this.getClass(), e.getReason()), e);
            throw e;
        } catch (Exception e) {
            logger.error(String.format(LOG_WITHDRAW_FAILED, this.getClass(), e.getMessage()), e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, ERROR_WITHDRAW_FAILED);
        }
    }

    @GetMapping("/{accountExtId}/transactions")
    @Operation(summary = "Get transaction report for an account using extId within a date range")
    @SecurityRequirement(name = "Bearer Authentication")
    public List<TransactionDTO> getTransactionReport(
            @PathVariable("accountExtId") String accountExtId,
            @RequestParam @DateTimeFormat(pattern = DAY_MONTH_YEAR_FORMAT) LocalDate startDate,
            @RequestParam @DateTimeFormat(pattern = DAY_MONTH_YEAR_FORMAT) LocalDate endDate,
            @RequestAttribute String username) {
        try {
            logger.info(String.format(LOG_GET_TRANSACTIONS, this.getClass(), accountExtId, startDate, endDate, username));

            LocalDateTime startDateTime = startDate.atStartOfDay();
            LocalDateTime endDateTime = endDate.atTime(23, 59, 59);

            Optional<Account> accountOpt = accountRepository.findByExtId(accountExtId);
            if (accountOpt.isEmpty()) {
                logger.error(LOG_GET_ACCOUNT_NOT_FOUND);
                throw new ResponseStatusException(HttpStatus.FORBIDDEN, LOG_GET_ACCOUNT_NOT_FOUND + username);
            }

            Account account = accountOpt.get();

            User accountOwner = userRepository.findById(account.getUserId())
                    .orElseThrow(() -> new ResponseStatusException(HttpStatus.FORBIDDEN, USER_DOES_NOT_EXIST));

            if (!accountOwner.getUsername().equals(username)) {
                throw new ResponseStatusException(HttpStatus.FORBIDDEN, UNAUTHORIZED_USER_ACCESS);
            }

            List<Transaction> transactions = accountService.getTransactionReport(account.getId(), startDateTime, endDateTime);

            return transactions.stream()
                    .map(transaction -> new TransactionDTO(
                            account.getExtId(),
                            transaction.getTransactionType().name(),
                            transaction.getAmount(),
                            transaction.getDescription(),
                            transaction.getTransactionDate()))
                    .toList();

        } catch (ResponseStatusException e) {
            logger.error(String.format(LOG_GET_TRANSACTIONS_FAILED, this.getClass(), accountExtId, e.getReason()), e);
            throw e;
        } catch (Exception e) {
            logger.error(String.format(LOG_GET_TRANSACTIONS_FAILED, this.getClass(), accountExtId, e.getMessage()), e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, ERROR_TRANSACTIONS_FAILED);
        }
    }

}
