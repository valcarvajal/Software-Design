package edu.ic6821.banca.accounts;

public enum AccountCurrencyType {
    DOLAR, COLON
}
