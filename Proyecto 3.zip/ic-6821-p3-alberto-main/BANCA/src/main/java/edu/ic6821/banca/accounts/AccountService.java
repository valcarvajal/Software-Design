package edu.ic6821.banca.accounts;

import edu.ic6821.banca.accounts.model.Transaction;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

public interface AccountService {

    boolean transfer(String fromIban, String toIban, BigDecimal amount);

    boolean withdraw(String iban, BigDecimal amount);

    List<Transaction> getTransactionReport(Long accountId, LocalDateTime startDate, LocalDateTime endDate);
}
