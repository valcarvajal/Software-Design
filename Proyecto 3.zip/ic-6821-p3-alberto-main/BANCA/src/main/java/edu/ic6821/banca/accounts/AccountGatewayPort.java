package edu.ic6821.banca.accounts;

import edu.ic6821.banca.accounts.TransactionDTO;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

public interface AccountGatewayPort {

    void transfer(String fromIban, String toIban, BigDecimal amount, String username);

    void withdraw(String iban, BigDecimal amount, String username);

    List<TransactionDTO> getTransactionReport(String accountExtId, LocalDate startDate, LocalDate endDate, String username);
}
