package edu.ic6821.banca.payment;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@Service
public class PaymentGatewayService {

    private final List<PaymentGatewayPort> paymentAdapters;

    @Autowired
    public PaymentGatewayService(List<PaymentGatewayPort> paymentAdapters) {
        this.paymentAdapters = paymentAdapters;
    }

    public boolean processDeposit(String accountId, String secondIdentifier, BigDecimal amount, PaymentMethod paymentMethod) {
        Optional<PaymentGatewayPort> paymentAdapter = getPaymentAdapterForMethod(paymentMethod);

        return paymentAdapter.map(paymentGatewayPort -> paymentGatewayPort.deposit(accountId, secondIdentifier, amount)).orElse(false);

    }

    private Optional<PaymentGatewayPort> getPaymentAdapterForMethod(PaymentMethod paymentMethod) {

        return paymentAdapters.stream()
                .filter(adapter -> {
                    if (paymentMethod == PaymentMethod.CREDIT_CARD && adapter instanceof CreditCardPaymentAdapter) {
                        return true;
                    } else if (paymentMethod == PaymentMethod.MANUAL_BANK_DEPOSIT && adapter instanceof ManualBankDepositAdapter) {
                        return true;
                    } else return paymentMethod == PaymentMethod.SINPE && adapter instanceof SinpePaymentAdapter;
                })
                .findFirst();
    }
}