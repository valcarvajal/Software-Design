package edu.ic6821.banca.payment;

import edu.ic6821.banca.accounts.AccountRepository;
import edu.ic6821.banca.accounts.AccountService;
import edu.ic6821.banca.accounts.model.Account;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.math.BigDecimal;
import java.util.Optional;

@Component
public class CreditCardPaymentAdapter implements PaymentGatewayPort {

    private static final Logger logger = LoggerFactory.getLogger(CreditCardPaymentAdapter.class);
    private static final String USER_NOT_FOUND = "Cuentas no encontradas para los IBAN proporcionados.";
    private static final String TRANSACTION_ERROR = "Error en el procesamiento de depósito con tarjeta de crédito: {}";
    private static final String CALLBACK_SUCCESSFUL = "Callback tarjeta de crédito realizado a {} con estado {}";
    private static final String CALLBACK_UNSUCCESSFUL = "Error al realizar el callback a {}: {}";
    private static final String CALLBACK_URL = "http://callback-url-creditcard.com";

    private final RestTemplate restTemplate = new RestTemplate();
    private final AccountRepository accountRepository;
    private final AccountService accountService;

    public CreditCardPaymentAdapter(final AccountRepository accountRepository, final AccountService accountService) {
        this.accountRepository = accountRepository;
        this.accountService = accountService;
    }

    @Override
    public boolean deposit(String accountId, String secondIdentifier, BigDecimal amount) {
        try {
            Optional<Account> fromAccount = accountRepository.findByIBAN(accountId);
            Optional<Account> toAccount = accountRepository.findByIBAN(secondIdentifier);

            if (fromAccount.isEmpty() || toAccount.isEmpty()) {
                logger.error(USER_NOT_FOUND);
                return false;
            }

            boolean transferSuccess = accountService.transfer(accountId, secondIdentifier, amount);
            sendCallback(CALLBACK_URL, transferSuccess);
            return transferSuccess;

        } catch (Exception e) {
            logger.error(TRANSACTION_ERROR, e.getMessage());
            return false;
        }
    }

    private void sendCallback(String callbackUrl, boolean depositStatus) {
        try {
            restTemplate.postForLocation(callbackUrl, null);
            logger.info(CALLBACK_SUCCESSFUL, callbackUrl, depositStatus);
        } catch (Exception e) {
            logger.error(CALLBACK_UNSUCCESSFUL, callbackUrl, e.getMessage());
        }
    }
}

