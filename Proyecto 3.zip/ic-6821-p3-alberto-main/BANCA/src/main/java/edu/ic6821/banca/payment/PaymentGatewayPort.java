package edu.ic6821.banca.payment;

import java.math.BigDecimal;

public interface PaymentGatewayPort {

    boolean deposit(String accountId, String secondIdentifier, BigDecimal amount);
}
