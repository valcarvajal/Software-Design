package edu.ic6821.banca.accounts;

public enum TransactionType {
    INGRESO, EGRESO
}