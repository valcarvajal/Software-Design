package edu.ic6821.banca.users;

public record SignUpDTO(SignUpStatus status, String username, String extId) {
}
