package edu.ic6821.banca.accounts;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public record TransactionDTO(String accountExtId, String transactionType, BigDecimal amount,
                             String description, LocalDateTime transactionDate) {
}
