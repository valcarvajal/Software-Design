package edu.ic6821.banca.accounts;

import edu.ic6821.banca.accounts.model.Account;
import edu.ic6821.banca.accounts.model.Transaction;
import edu.ic6821.banca.users.UserRepository;
import edu.ic6821.banca.users.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class AccountServiceImpl implements AccountService {

    private static final String DEFAULT_MESSAGE_WITHDRAWAL = "Withdrawal";
    private static final String DEFAULT_MESSAGE_TRANSFER = "Transfer to ";

    @Autowired
    private AccountRepository accountRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private TransactionRepository transactionRepository;

    @Override
    public boolean transfer(String fromIban, String toIban, BigDecimal amount) {
        Optional<Account> fromAccountOpt = accountRepository.findByIBAN(fromIban);
        Optional<Account> toAccountOpt = accountRepository.findByIBAN(toIban);

        if (fromAccountOpt.isPresent() && toAccountOpt.isPresent()) {
            Account fromAccount = fromAccountOpt.get();
            Account toAccount = toAccountOpt.get();

            if (fromAccount.getInitialBalance().compareTo(amount) >= 0) {
                fromAccount.setInitialBalance(fromAccount.getInitialBalance().subtract(amount));
                toAccount.setInitialBalance(toAccount.getInitialBalance().add(amount));

                accountRepository.save(fromAccount);
                accountRepository.save(toAccount);

                Transaction withdrawalTransaction = new Transaction(fromAccount, TransactionType.EGRESO, amount, DEFAULT_MESSAGE_TRANSFER + toIban);
                transactionRepository.save(withdrawalTransaction);

                Transaction depositTransaction = new Transaction(toAccount, TransactionType.INGRESO, amount, DEFAULT_MESSAGE_TRANSFER + fromIban);
                transactionRepository.save(depositTransaction);

                return true;
            }
        }
        return false;
    }

    @Override
    public boolean withdraw(String iban, BigDecimal amount) {
        Optional<Account> accountOpt = accountRepository.findByIBAN(iban);
        if (accountOpt.isPresent()) {
            Account account = accountOpt.get();

            if (account.getInitialBalance().compareTo(amount) >= 0) {
                account.setInitialBalance(account.getInitialBalance().subtract(amount));
                accountRepository.save(account);

                Transaction withdrawalTransaction = new Transaction(account, TransactionType.EGRESO, amount, DEFAULT_MESSAGE_WITHDRAWAL);
                transactionRepository.save(withdrawalTransaction);

                return true;
            }
        }
        return false;
    }

    @Override
    public List<Transaction> getTransactionReport(Long accountId, LocalDateTime startDate, LocalDateTime endDate) {
        return transactionRepository.findTransactionsByAccountAndDateRange(accountId, startDate, endDate);
    }
}
