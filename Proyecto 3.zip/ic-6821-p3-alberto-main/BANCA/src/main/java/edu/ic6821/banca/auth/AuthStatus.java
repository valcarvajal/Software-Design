package edu.ic6821.banca.auth;

public enum AuthStatus {
    AUTH_SUCCEEDED, AUTH_FAILED
}
