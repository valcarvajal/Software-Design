package edu.ic6821.banca.auth;

public record IdentityDTO(String username) {
}
