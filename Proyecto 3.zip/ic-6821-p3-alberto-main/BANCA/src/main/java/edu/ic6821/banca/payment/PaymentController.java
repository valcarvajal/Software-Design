package edu.ic6821.banca.payment;

import edu.ic6821.banca.accounts.AccountRepository;
import edu.ic6821.banca.accounts.model.Account;
import edu.ic6821.banca.users.UserRepository;
import edu.ic6821.banca.users.model.User;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.math.BigDecimal;
import java.util.Optional;

@RestController
@RequestMapping("/api/payment")
@SecurityRequirement(name = "Bearer Authentication")
public class PaymentController {

    private static final Logger logger = LoggerFactory.getLogger(PaymentController.class);
    private static final String PROCESSING_DEPOSIT = "Processing deposit. FirstIdentifier: {}, SecondIdentifier: {}, Amount: {}, PaymentMethod: {}";
    private static final String ACCOUNT_DOES_NOT_EXIST = "La cuenta de origen no existe";
    private static final String USER_DOES_NOT_EXIST = "El propietario de la cuenta no existe";
    private static final String LOG_ACCESS_DENIED = "Acceso denegado: El usuario autenticado ({}) no coincide con el propietario de la cuenta ({})";
    private static final String ACCESS_DENIED_MESSAGE = "El usuario no tiene permiso para realizar esta transacción";
    private static final String LOG_ACCESS_GRANTED = "Permiso concedido: El usuario autenticado coincide con el propietario de la cuenta.";
    private static final String LOG_DEPOSIT_FAILED = "Deposit failed for FirstIdentifier: {}, SecondIdentifier: {}, PaymentMethod: {}";
    private static final String DEPOSIT_FAILED_MESSAGE = "Depósito fallido";
    private static final String LOG_DEPOSIT_SUCCESSFUL = "Deposit successful for FirstIdentifier: {}, PaymentMethod: {}";
    private static final String LOG_DEPOSIT_ERROR = "Error processing deposit. FirstIdentifier: {}, SecondIdentifier: {}, PaymentMethod: {}, Error: {}";
    private static final String LOG_DEPOSIT_UNEXPECTED_ERROR = "Unexpected error processing deposit for FirstIdentifier: {}: {}";
    private static final String ERROR_INTERNAL_SERVER_MESSAGE = "Error interno en el servidor";

    @Autowired
    private PaymentGatewayService paymentService;

    @Autowired
    private AccountRepository accountRepository;

    @Autowired
    private UserRepository userRepository;

    @PostMapping("/deposit")
    @ResponseStatus(HttpStatus.CREATED)
    public void deposit(
            @RequestParam String firstIdentifier,
            @RequestParam String secondIdentifier,
            @RequestParam BigDecimal amount,
            @RequestParam PaymentMethod paymentMethod,
            @RequestAttribute String username) {

        try {
            logger.info(PROCESSING_DEPOSIT, firstIdentifier, secondIdentifier, amount, paymentMethod);

            Optional<User> userOpt = userRepository.findByPhoneNumber(firstIdentifier);

            User accountOwner = userOpt.orElseGet(() -> {
                Account account = accountRepository.findByIBAN(firstIdentifier)
                        .orElseThrow(() -> new ResponseStatusException(HttpStatus.FORBIDDEN, ACCOUNT_DOES_NOT_EXIST));

                return userRepository.findById(account.getUserId())
                        .orElseThrow(() -> new ResponseStatusException(HttpStatus.FORBIDDEN, USER_DOES_NOT_EXIST));
            });

            if (!accountOwner.getUsername().equals(username)) {
                logger.warn(LOG_ACCESS_DENIED, username, accountOwner.getUsername());
                throw new ResponseStatusException(HttpStatus.FORBIDDEN, ACCESS_DENIED_MESSAGE);
            }

            logger.info(LOG_ACCESS_GRANTED);

            boolean success = paymentService.processDeposit(firstIdentifier, secondIdentifier, amount, paymentMethod);
            if (!success) {
                logger.warn(LOG_DEPOSIT_FAILED, firstIdentifier, secondIdentifier, paymentMethod);
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, DEPOSIT_FAILED_MESSAGE);
            }

            logger.info(LOG_DEPOSIT_SUCCESSFUL, firstIdentifier, paymentMethod);

        } catch (ResponseStatusException e) {
            logger.error(LOG_DEPOSIT_ERROR, firstIdentifier, secondIdentifier, paymentMethod, e.getReason(), e);
            throw e;
        } catch (Exception e) {
            logger.error(LOG_DEPOSIT_UNEXPECTED_ERROR, firstIdentifier, e.getMessage(), e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, ERROR_INTERNAL_SERVER_MESSAGE, e);
        }
    }
}
