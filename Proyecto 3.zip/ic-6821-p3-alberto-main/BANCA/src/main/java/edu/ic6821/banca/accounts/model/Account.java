package edu.ic6821.banca.accounts.model;

import edu.ic6821.banca.framework.model.BaseEntity;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

import java.math.BigDecimal;
import java.util.Date;
import java.util.Objects;

@Entity
@Table(name = "accounts")
public class Account extends BaseEntity {
    private String IBAN;
    private BigDecimal initialBalance;
    private String currencyType;
    private Long userId;

    public Account() {
    }

    public Account(String IBAN, BigDecimal initialBalance, String currencyType, Long userId) {
        this.IBAN = IBAN;
        this.initialBalance = initialBalance;
        this.currencyType = currencyType;
        this.userId = userId;
    }

    public String getIBAN() {
        return IBAN;
    }

    public void setIBAN(String IBAN) {
        this.IBAN = IBAN;
    }

    public BigDecimal getInitialBalance() {
        return initialBalance;
    }

    public void setInitialBalance(BigDecimal initialBalance) {
        this.initialBalance = initialBalance;
    }

    public String getCurrencyType() {
        return currencyType;
    }

    public void setCurrencyType(String currencyType) {
        this.currencyType = currencyType;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        Account account = (Account) o;
        return Objects.equals(IBAN, account.IBAN) &&
                Objects.equals(initialBalance, account.initialBalance) &&
                Objects.equals(currencyType, account.currencyType) &&
                Objects.equals(userId, account.userId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), IBAN, initialBalance, currencyType, userId);
    }

    @Override
    public String toString() {
        return "Account{" +
                ", IBAN='" + IBAN + '\'' +
                ", initialBalance=" + initialBalance +
                ", currencyType=" + currencyType +
                ", userId=" + userId +
                '}';
    }
}

