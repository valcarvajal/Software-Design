package edu.ic6821.banca.auth;

public record AuthDTO(AuthStatus status, String token) {
}
