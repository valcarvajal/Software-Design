package edu.ic6821.banca.payment;

public enum PaymentMethod {
    SINPE,
    CREDIT_CARD,
    MANUAL_BANK_DEPOSIT
}
