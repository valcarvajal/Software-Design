Para correr el demo

```bash
./gradlew bootRun
```

Para correr las pruebas

```bash
./gradlew clean test
```

Documentación del API

```html
http://localhost:8080/swagger-ui/index.html
```

