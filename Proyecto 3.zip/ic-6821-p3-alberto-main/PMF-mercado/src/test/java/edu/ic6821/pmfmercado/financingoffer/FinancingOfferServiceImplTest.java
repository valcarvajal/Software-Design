package edu.ic6821.pmfmercado.financingoffer;

import edu.ic6821.pmfmercado.client.BankClient;
import edu.ic6821.pmfmercado.client.CcfClient;
import edu.ic6821.pmfmercado.client.PmfRiesgoClient;
import edu.ic6821.pmfmercado.proposal.Proposal;
import edu.ic6821.pmfmercado.proposal.ProposalRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.math.BigDecimal;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class FinancingOfferServiceImplTest {

    @Mock
    private ProposalRepository proposalRepository;

    @Mock
    private FinancingOfferRepository financingOfferRepository;

    @Mock
    private BankClient bankClient;

    @Mock
    private CcfClient ccfClient;

    @Mock
    private PmfRiesgoClient pmfRiesgoClient;

    @InjectMocks
    private FinancingOfferServiceImpl financingOfferService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void create_ValidOfferAndPendingAmountZero_ShouldCreateOfferAndTriggerDisbursement() {
        String proposalExtId = "proposal123";
        String lenderId = "lender1";
        BigDecimal amountOffered = new BigDecimal("1000");

        Proposal proposal = new Proposal("Description", new BigDecimal("1000"), 12, "Pending", new BigDecimal("0.05"));
        proposal.setAmountPending(new BigDecimal("1000"));
        when(proposalRepository.findByExtId(proposalExtId)).thenReturn(Optional.of(proposal));

        Optional<FinancingOffer> result = financingOfferService.create(proposalExtId, lenderId, amountOffered);

        assertTrue(result.isPresent());
        assertEquals(BigDecimal.ZERO, proposal.getAmountPending());
        assertEquals("Financed", proposal.getStatus());
        verify(bankClient, times(1)).disburseFunds(proposalExtId);
    }

    @Test
    void create_ValidOfferAndPendingAmountNotZero_ShouldCreateOffer() {
        String proposalExtId = "proposal123";
        String lenderId = "lender1";
        BigDecimal amountOffered = new BigDecimal("500");

        Proposal proposal = new Proposal("Description", new BigDecimal("1000"), 12, "Pending", new BigDecimal("0.05"));
        proposal.setAmountPending(new BigDecimal("1000"));
        when(proposalRepository.findByExtId(proposalExtId)).thenReturn(Optional.of(proposal));

        Optional<FinancingOffer> result = financingOfferService.create(proposalExtId, lenderId, amountOffered);

        assertTrue(result.isPresent());
        assertEquals(new BigDecimal("500"), proposal.getAmountPending());
        verify(bankClient, never()).disburseFunds(proposalExtId);
    }

    @Test
    void create_NullProposalExtId_ShouldThrowException() {
        String lenderId = "lender1";
        BigDecimal amountOffered = BigDecimal.valueOf(100);

        assertThrows(IllegalArgumentException.class, () -> financingOfferService.create(null, lenderId, amountOffered));
    }

    @Test
    void create_OfferAmountZeroOrLess_ShouldThrowException() {
        String proposalExtId = "proposal123";
        String lenderId = "lender1";
        BigDecimal amountOffered = BigDecimal.ZERO;

        Proposal proposal = new Proposal("Description", new BigDecimal("1000"), 12, "Pending", new BigDecimal("0.05"));
        when(proposalRepository.findByExtId(proposalExtId)).thenReturn(Optional.of(proposal));

        assertThrows(IllegalArgumentException.class, () -> financingOfferService.create(proposalExtId, lenderId, amountOffered));
    }

    @Test
    void create_OfferExceedsPendingAmount_ShouldThrowException() {
        String proposalExtId = "proposal123";
        String lenderId = "lender1";
        BigDecimal amountOffered = new BigDecimal("1500");

        Proposal proposal = new Proposal("Description", new BigDecimal("1000"), 12, "Pending", new BigDecimal("0.05"));
        proposal.setAmountPending(new BigDecimal("1000"));
        when(proposalRepository.findByExtId(proposalExtId)).thenReturn(Optional.of(proposal));

        assertThrows(IllegalArgumentException.class, () -> financingOfferService.create(proposalExtId, lenderId, amountOffered));
    }

    @Test
    void create_FullFunding_ShouldTriggerDisbursement() {
        String proposalExtId = "proposal123";
        String lenderId = "lender1";
        BigDecimal amountOffered = new BigDecimal("1000");

        Proposal proposal = new Proposal("Description", new BigDecimal("1000"), 12, "Pending", new BigDecimal("0.05"));
        proposal.setAmountPending(new BigDecimal("1000"));
        when(proposalRepository.findByExtId(proposalExtId)).thenReturn(Optional.of(proposal));

        Optional<FinancingOffer> result = financingOfferService.create(proposalExtId, lenderId, amountOffered);

        assertTrue(result.isPresent());
        assertEquals(BigDecimal.ZERO, proposal.getAmountPending());
        assertEquals("Financed", proposal.getStatus());
        verify(bankClient, times(1)).disburseFunds(proposalExtId);
    }

    @Test
    void create_NotFullyFunded_ShouldNotTriggerDisbursement() {
        String proposalExtId = "proposal123";
        String lenderId = "lender1";
        BigDecimal amountOffered = new BigDecimal("500");

        Proposal proposal = new Proposal("Description", new BigDecimal("1000"), 12, "Pending", new BigDecimal("0.05"));
        proposal.setAmountPending(new BigDecimal("1000"));
        when(proposalRepository.findByExtId(proposalExtId)).thenReturn(Optional.of(proposal));

        Optional<FinancingOffer> result = financingOfferService.create(proposalExtId, lenderId, amountOffered);

        assertTrue(result.isPresent());
        assertEquals(new BigDecimal("500"), proposal.getAmountPending());
        verify(bankClient, never()).disburseFunds(proposalExtId);
    }
}
