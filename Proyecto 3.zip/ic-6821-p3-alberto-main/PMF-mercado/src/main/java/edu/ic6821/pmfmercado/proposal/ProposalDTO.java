package edu.ic6821.pmfmercado.proposal;

import java.math.BigDecimal;

public record ProposalDTO(String description, BigDecimal requestedAmount, int installments, String status, BigDecimal monthlyPayment, BigDecimal interestRate, BigDecimal amountPending, BigDecimal assignedRiskRating) {
}
