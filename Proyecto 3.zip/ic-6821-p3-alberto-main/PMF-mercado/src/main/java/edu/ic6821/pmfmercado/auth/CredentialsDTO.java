package edu.ic6821.pmfmercado.auth;

public record CredentialsDTO(String username, String password) {
}
