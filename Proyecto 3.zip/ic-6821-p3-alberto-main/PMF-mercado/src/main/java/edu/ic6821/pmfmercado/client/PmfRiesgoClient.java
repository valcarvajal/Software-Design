package edu.ic6821.pmfmercado.client;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.math.BigDecimal;

@Service
public class PmfRiesgoClient {

    private static final String PMF_RIESGO_API_URL = "http://localhost:8083"; // URL base del módulo PMF-Riesgo
    private final RestTemplate restTemplate;

    public PmfRiesgoClient(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public void evaluateRisk(String proposalId, BigDecimal riskPercentage) {
        String url = PMF_RIESGO_API_URL + "/api/pmf-riesgo/evaluate-risk/" + proposalId;
        restTemplate.postForLocation(url, riskPercentage);
    }
}
