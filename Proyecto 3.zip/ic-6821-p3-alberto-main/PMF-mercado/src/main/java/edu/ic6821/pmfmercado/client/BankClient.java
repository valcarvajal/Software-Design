package edu.ic6821.pmfmercado.client;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class BankClient {

    private static final String BANK_API_URL = "http://localhost:8081";

    private final RestTemplate restTemplate;

    public BankClient(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public void disburseFunds(String proposalId) {
        String url = BANK_API_URL + "/api/disbursements/" + proposalId;
        restTemplate.postForLocation(url, null);
    }
}
