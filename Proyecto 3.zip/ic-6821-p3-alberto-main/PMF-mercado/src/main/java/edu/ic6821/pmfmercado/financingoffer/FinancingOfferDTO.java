package edu.ic6821.pmfmercado.financingoffer;

import java.math.BigDecimal;

public record FinancingOfferDTO(String proposalExtId, BigDecimal amountOffered) {
}
