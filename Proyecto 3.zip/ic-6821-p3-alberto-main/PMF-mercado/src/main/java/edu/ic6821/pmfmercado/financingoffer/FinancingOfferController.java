package edu.ic6821.pmfmercado.financingoffer;

import edu.ic6821.pmfmercado.proposal.Proposal;
import edu.ic6821.pmfmercado.auth.AuthService;
import edu.ic6821.pmfmercado.auth.IdentityDTO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import java.util.Optional;
import java.math.BigDecimal;

@RestController
@RequestMapping("/api/financing-offer")
public class FinancingOfferController {

    private static final Logger logger = LoggerFactory.getLogger(FinancingOfferController.class);
    private static final String CREATE_LOG_FORMAT = "[%s.create] Creating new financing offer for proposal %s";
    private static final String INVALID_TOKEN_MESSAGE = "Invalid token";
    private static final String PROPOSAL_NOT_FOUND_MESSAGE = "Proposal not found";
    private static final String INTERNAL_SERVER_ERROR_MESSAGE = "Internal server error";
    private static final String AUTHORIZATION_HEADER_PREFIX = "Bearer ";
    private static final String AUTHORIZATION_HEADER_ERROR_MESSAGE = "Authorization header must start with Bearer";
    private static final String INVALID_INPUT_LOG_FORMAT = "[%s.create] Invalid input: %s";
    private static final String UNEXPECTED_ERROR_LOG_FORMAT = "[%s.create] Unexpected error: %s";
    private static final String BEARER_AUTHENTICATION = "Bearer Authentication";
    private static final String CREATE_FINANCING_OFFER_SUMMARY = "Create new financing offer";
    private static final int BEARER_PREFIX_LENGTH = 7;

    @Autowired
    private FinancingOfferService financingOfferService;

    @Autowired
    private AuthService authService;

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    @Operation(summary = CREATE_FINANCING_OFFER_SUMMARY)
    @SecurityRequirement(name = BEARER_AUTHENTICATION)
    public FinancingOfferResponseDTO create(
            @RequestHeader(HttpHeaders.AUTHORIZATION) String authorizationHeader,
            @RequestBody FinancingOfferDTO financingOfferDTO) {
        logger.info(String.format(CREATE_LOG_FORMAT, this.getClass(), financingOfferDTO.proposalExtId()));

        try {
            String token = extractToken(authorizationHeader);

            IdentityDTO identity = authService.validateToken(token);

            if (identity == null) {
                throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, INVALID_TOKEN_MESSAGE);
            }

            String lenderId = identity.username();

            Optional<FinancingOffer> optFinancingOffer = financingOfferService.create(
                    financingOfferDTO.proposalExtId(),
                    lenderId,
                    financingOfferDTO.amountOffered()
            );

            if (optFinancingOffer.isEmpty()) {
                throw new ResponseStatusException(HttpStatus.NOT_FOUND, PROPOSAL_NOT_FOUND_MESSAGE);
            }

            FinancingOffer financingOffer = optFinancingOffer.get();
            Proposal proposal = financingOffer.getProposal();

            BigDecimal amountPending = proposal.getRequestedAmount().subtract(proposal.getTotalAmountOffered());

            return new FinancingOfferResponseDTO(financingOffer.getExtId(), amountPending);

        } catch (IllegalArgumentException e) {
            logger.error(String.format(INVALID_INPUT_LOG_FORMAT, this.getClass(), e.getMessage()));
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        } catch (ResponseStatusException e) {
            throw e;
        } catch (Exception e) {
            logger.error(String.format(UNEXPECTED_ERROR_LOG_FORMAT, this.getClass(), e.getMessage()), e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, INTERNAL_SERVER_ERROR_MESSAGE);
        }
    }

    private String extractToken(String authorizationHeader) {
        if (authorizationHeader == null || !authorizationHeader.startsWith(AUTHORIZATION_HEADER_PREFIX)) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, AUTHORIZATION_HEADER_ERROR_MESSAGE);
        }
        return authorizationHeader.substring(BEARER_PREFIX_LENGTH).trim();
    }
}
