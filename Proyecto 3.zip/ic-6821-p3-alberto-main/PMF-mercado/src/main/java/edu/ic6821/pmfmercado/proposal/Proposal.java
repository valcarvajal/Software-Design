package edu.ic6821.pmfmercado.proposal;

import edu.ic6821.pmfmercado.financingoffer.FinancingOffer;
import edu.ic6821.pmfmercado.framework.model.BaseEntity;
import jakarta.persistence.*;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

@Entity
@Table(name = "proposals")
public class Proposal extends BaseEntity {

    private static final String MAPPED_BY = "proposal";
    private static final String TO_STRING_PREFIX = "Proposal{";
    private static final String TO_STRING_DESCRIPTION = "description='";
    private static final String TO_STRING_REQUESTED_AMOUNT = ", requestedAmount=";
    private static final String TO_STRING_INSTALLMENTS = ", installments=";
    private static final String TO_STRING_STATUS = ", status='";
    private static final String TO_STRING_AMOUNT_PENDING = ", amountPending=";
    private static final String TO_STRING_MONTHLY_PAYMENT = ", monthlyPayment=";
    private static final String TO_STRING_ASSIGNED_RISK_RATING = ", assignedRiskRating=";
    private static final String TO_STRING_SUFFIX = "} ";
    private static final String SINGLE_QUOTE = "'";

    private String description;
    private BigDecimal requestedAmount;
    private String status;

    @OneToMany(mappedBy = MAPPED_BY, cascade = CascadeType.ALL)
    private List<FinancingOffer> financingOffers;

    @Column(nullable = true)
    private Integer installments;

    @Column(nullable = false)
    private BigDecimal amountPending;

    @Column(nullable = true)
    private BigDecimal monthlyPayment;

    @Column(nullable = false)
    private BigDecimal totalAmountOffered = BigDecimal.ZERO;

    private BigDecimal assignedRiskRating;

    @Column(nullable = false)
    private BigDecimal interestRate;

    public Proposal() {
    }

    public Proposal(String description, BigDecimal requestedAmount, int installments, String status,
                    BigDecimal monthlyPayment, BigDecimal interestRate, BigDecimal amountPending,
                    BigDecimal assignedRiskRating) {
        this.description = description;
        this.requestedAmount = requestedAmount;
        this.installments = installments;
        this.status = status;
        this.monthlyPayment = monthlyPayment;
        this.interestRate = interestRate;
        this.amountPending = amountPending;
        this.assignedRiskRating = assignedRiskRating;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public BigDecimal getRequestedAmount() {
        return requestedAmount;
    }

    public void setRequestedAmount(BigDecimal requestedAmount) {
        this.requestedAmount = requestedAmount;
    }

    public Integer getInstallments() {
        return installments;
    }

    public void setInstallments(Integer installments) {
        this.installments = installments;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public List<FinancingOffer> getFinancingOffers() {
        return financingOffers;
    }

    public void setFinancingOffers(List<FinancingOffer> financingOffers) {
        this.financingOffers = financingOffers;
    }

    public BigDecimal getAmountPending() {
        return amountPending;
    }

    public void setAmountPending(BigDecimal amountPending) {
        this.amountPending = amountPending;
    }

    public BigDecimal getMonthlyPayment() {
        return monthlyPayment;
    }

    public void setMonthlyPayment(BigDecimal monthlyPayment) {
        this.monthlyPayment = monthlyPayment;
    }

    public BigDecimal getTotalAmountOffered() {
        return totalAmountOffered;
    }

    public void setTotalAmountOffered(BigDecimal totalAmountOffered) {
        this.totalAmountOffered = totalAmountOffered;
    }

    public BigDecimal getAssignedRiskRating() {
        return assignedRiskRating;
    }

    public void setAssignedRiskRating(BigDecimal assignedRiskRating) {
        this.assignedRiskRating = assignedRiskRating;
    }

    public BigDecimal getInterestRate() {
        return interestRate;
    }

    public void setInterestRate(BigDecimal interestRate) {
        this.interestRate = interestRate;
    }

    public void setInstallmentsFromMonthlyPayment() {
        if (monthlyPayment.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Monthly payment must be greater than zero.");
        }
        this.installments = requestedAmount.divide(monthlyPayment, RoundingMode.HALF_UP).intValue();
    }

    @Override
    public String toString() {
        return TO_STRING_PREFIX +
                TO_STRING_DESCRIPTION + description + SINGLE_QUOTE +
                TO_STRING_REQUESTED_AMOUNT + requestedAmount +
                TO_STRING_INSTALLMENTS + installments +
                TO_STRING_MONTHLY_PAYMENT + monthlyPayment +
                TO_STRING_AMOUNT_PENDING + amountPending +
                TO_STRING_ASSIGNED_RISK_RATING + assignedRiskRating +
                TO_STRING_STATUS + status + SINGLE_QUOTE +
                TO_STRING_SUFFIX + super.toString();
    }
}
