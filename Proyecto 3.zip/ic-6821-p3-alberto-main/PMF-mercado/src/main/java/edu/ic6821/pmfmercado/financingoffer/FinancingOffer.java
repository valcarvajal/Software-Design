package edu.ic6821.pmfmercado.financingoffer;

import edu.ic6821.pmfmercado.framework.model.BaseEntity;
import edu.ic6821.pmfmercado.proposal.Proposal;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.util.Objects;

@Entity
@Table(name = "financing_offers")
public class FinancingOffer extends BaseEntity {

    private static final String PROPOSAL_ID_COLUMN = "proposal_id";
    private static final String TO_STRING_PREFIX = "FinancingOffer{";
    private static final String TO_STRING_PROPOSAL = "proposal=";
    private static final String TO_STRING_LENDER_ID = ", lenderId='";
    private static final String TO_STRING_AMOUNT_OFFERED = "', amountOffered=";
    private static final String TO_STRING_SUFFIX = "} ";
    private static final char BACKSLASH = '\'';

    @ManyToOne
    @JoinColumn(name = PROPOSAL_ID_COLUMN, nullable = false)
    private Proposal proposal;

    @Column(nullable = false)
    private String lenderId;

    @Column(nullable = false)
    private BigDecimal amountOffered;

    public FinancingOffer() {
    }

    public FinancingOffer(Proposal proposal, String lenderId, BigDecimal amountOffered) {
        this.proposal = proposal;
        this.lenderId = lenderId;
        this.amountOffered = amountOffered;
    }

    public Proposal getProposal() {
        return proposal;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        FinancingOffer that = (FinancingOffer) o;

        return Objects.equals(getExtId(), that.getExtId());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getExtId());
    }

    @Override
    public String toString() {
        return TO_STRING_PREFIX +
                TO_STRING_PROPOSAL + proposal +
                TO_STRING_LENDER_ID + lenderId + BACKSLASH +
                TO_STRING_AMOUNT_OFFERED + amountOffered +
                TO_STRING_SUFFIX + super.toString();
    }
}
