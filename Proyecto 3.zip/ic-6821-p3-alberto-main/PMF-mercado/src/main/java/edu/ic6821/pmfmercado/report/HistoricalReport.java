package edu.ic6821.pmfmercado.report;

import edu.ic6821.pmfmercado.framework.model.BaseEntity;
import jakarta.persistence.*;
import java.math.BigDecimal;

@Entity
@Table(name = "historical_reports")
public class HistoricalReport extends BaseEntity {
    
    @Column(name = "proposal_id", nullable = false)
    private Long proposalId;  

    @Column(name = "ext_id", nullable = false)
    private String extId;

    @Column(nullable = false)
    private String description;

    @Column(name = "requested_amount", nullable = false)
    private BigDecimal requestedAmount;

    @Column(nullable = false)
    private String status;

    public HistoricalReport() {
    }

    public HistoricalReport(Long proposalId, String extId, String description, BigDecimal requestedAmount, String status) {
        this.proposalId = proposalId;
        this.extId = extId;
        this.description = description;
        this.requestedAmount = requestedAmount;
        this.status = status;
    }

    public Long getProposalId() {
        return proposalId;
    }

    public void setProposalId(Long proposalId) {
        this.proposalId = proposalId;
    }

    public String getExtId() {
        return extId;
    }

    public void setExtId(String extId) {
        this.extId = extId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public BigDecimal getRequestedAmount() {
        return requestedAmount;
    }

    public void setRequestedAmount(BigDecimal requestedAmount) {
        this.requestedAmount = requestedAmount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "HistoricalReport{" +
                "proposalId=" + proposalId +
                ", extId='" + extId + '\'' +
                ", description='" + description + '\'' +
                ", requestedAmount=" + requestedAmount +
                ", status='" + status + '\'' +
                "} " + super.toString();
    }
}

