package edu.ic6821.pmfmercado.auth;

public record AuthDTO(AuthStatus status, String token) {
}
