package edu.ic6821.pmfmercado.users;

public enum SignUpStatus {
    SIGN_UP_FAILED_USERNAME_EXISTS, SIGN_UP_SUCCEEDED
}
