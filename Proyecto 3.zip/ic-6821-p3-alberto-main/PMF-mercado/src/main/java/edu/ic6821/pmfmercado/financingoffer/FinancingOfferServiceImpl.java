package edu.ic6821.pmfmercado.financingoffer;

import edu.ic6821.pmfmercado.client.BankClient;
import edu.ic6821.pmfmercado.client.CcfClient;
import edu.ic6821.pmfmercado.client.PmfRiesgoClient;
import edu.ic6821.pmfmercado.proposal.Proposal;
import edu.ic6821.pmfmercado.proposal.ProposalRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.util.Optional;

@Service
public class FinancingOfferServiceImpl implements FinancingOfferService {

    private static final Logger logger = LoggerFactory.getLogger(FinancingOfferServiceImpl.class);
    private static final String PROPOSAL_NOT_EXIST_MESSAGE = "Proposal does not exist";
    private static final String OFFER_MUST_BE_GREATER_THAN_ZERO_MESSAGE = "The offer must be greater than 0";
    private static final String OFFER_EXCEEDS_PENDING_AMOUNT_MESSAGE = "The offer exceeds the proposal's pending amount";
    private static final String FINANCED_STATUS = "Financed";

    @Autowired
    private ProposalRepository proposalRepository;

    @Autowired
    private FinancingOfferRepository financingOfferRepository;

    @Autowired
    private BankClient bankClient;

    @Autowired
    private CcfClient ccfClient;

    @Autowired
    private PmfRiesgoClient pmfRiesgoClient;

    @Override
    public Optional<FinancingOffer> create(String proposalExtId, String lenderId, BigDecimal amountOffered) {
        logger.info("Attempting to create a financing offer for proposal {}", proposalExtId);

        Proposal proposal = proposalRepository.findByExtId(proposalExtId)
                .orElseThrow(() -> new IllegalArgumentException(PROPOSAL_NOT_EXIST_MESSAGE));

        if (amountOffered.compareTo(BigDecimal.ZERO) <= 0) {
            logger.error(OFFER_MUST_BE_GREATER_THAN_ZERO_MESSAGE);
            throw new IllegalArgumentException(OFFER_MUST_BE_GREATER_THAN_ZERO_MESSAGE);
        }

        if (amountOffered.compareTo(proposal.getAmountPending()) > 0) {
            logger.error(OFFER_EXCEEDS_PENDING_AMOUNT_MESSAGE);
            throw new IllegalArgumentException(OFFER_EXCEEDS_PENDING_AMOUNT_MESSAGE);
        }

        BigDecimal updatedPendingAmount = proposal.getAmountPending().subtract(amountOffered);
        proposal.setAmountPending(updatedPendingAmount);
        proposalRepository.save(proposal);

        FinancingOffer financingOffer = new FinancingOffer(proposal, lenderId, amountOffered);
        financingOfferRepository.save(financingOffer);

        if (updatedPendingAmount.compareTo(BigDecimal.ZERO) == 0) {
            proposal.setStatus(FINANCED_STATUS);
            proposalRepository.save(proposal);

            logger.info("Proposal {} is now fully financed.", proposalExtId);
            bankClient.disburseFunds(proposalExtId);
        }

        BigDecimal riskPercentage = ccfClient.getRiskRating(proposalExtId);
        pmfRiesgoClient.evaluateRisk(proposalExtId, riskPercentage);

        return Optional.of(financingOffer);
    }
}
