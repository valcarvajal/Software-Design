package edu.ic6821.pmfmercado.payment;

import edu.ic6821.pmfmercado.client.BankClient;
import edu.ic6821.pmfmercado.proposal.Proposal;
import edu.ic6821.pmfmercado.proposal.ProposalRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.List;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Service
public class PaymentService {

    private static final Logger logger = LoggerFactory.getLogger(PaymentService.class);
    private static final BigDecimal PMF_SHARE_PERCENTAGE = new BigDecimal("0.7"); // 70% para PMF-Mercado
    private static final BigDecimal CCF_SHARE_PERCENTAGE = new BigDecimal("0.3"); // 30% para CCF

    @Autowired
    private ProposalRepository proposalRepository;

    @Autowired
    private PaymentRepository paymentRepository;

    @Autowired
    private BankClient bankClient;

    public void processPayment(String proposalExtId, BigDecimal paymentAmount) {
        Proposal proposal = proposalRepository.findByExtId(proposalExtId)
                .orElseThrow(() -> new IllegalArgumentException("Proposal not found"));

        BigDecimal interest = paymentAmount.multiply(proposal.getInterestRate());
        BigDecimal pmfShare = interest.multiply(PMF_SHARE_PERCENTAGE);
        BigDecimal ccfShare = interest.multiply(CCF_SHARE_PERCENTAGE);

        BigDecimal principalPayment = paymentAmount.subtract(interest);
        BigDecimal newAmountPending = proposal.getAmountPending().subtract(principalPayment);

        proposal.setAmountPending(newAmountPending);

        proposal.setInstallments(proposal.getInstallments() - 1);
        proposalRepository.save(proposal);

        Payment payment = new Payment(proposal, paymentAmount, interest, LocalDateTime.now());
        paymentRepository.save(payment);

        logger.info("Interest distributed: PMF-Mercado = {}, CCF = {}", pmfShare, ccfShare);

        if (newAmountPending.compareTo(BigDecimal.ZERO) == 0 || proposal.getInstallments() <= 0) {
            proposal.setStatus("Paid");
            proposalRepository.save(proposal);
            logger.info("Proposal {} is fully paid or has expired.", proposalExtId);

            generatePaymentReport(proposal);
        }
    }

    private void generatePaymentReport(Proposal proposal) {
        String reportFileName = "Payment_Report_" + proposal.getExtId() + ".txt";

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(reportFileName))) {
            writer.write("Reporte de Pagos - Propuesta: " + proposal.getExtId());
            writer.newLine();
            writer.write("Descripción: " + proposal.getDescription());
            writer.newLine();
            writer.write("Monto solicitado original: " + proposal.getRequestedAmount());
            writer.newLine();
            writer.write("Interés aplicado: " + proposal.getInterestRate());
            writer.newLine();
            writer.write("Estatus final de la propuesta: " + proposal.getStatus());
            writer.newLine();
            writer.write("Total de pagos realizados: " + proposal.getInstallments());
            writer.newLine();
            writer.newLine();

            List<Payment> payments = paymentRepository.findByProposal(proposal);
            writer.write("Historial de Pagos:");
            writer.newLine();
            writer.write("-----------------------------");
            writer.newLine();

            for (Payment payment : payments) {
                writer.write("Fecha del pago: " + payment.getPaymentDate());
                writer.newLine();
                writer.write("Monto pagado: " + payment.getAmount());
                writer.newLine();
                writer.write("Monto de interés: " + payment.getInterest());
                writer.newLine();
                writer.write("-----------------------------");
                writer.newLine();
            }

            writer.write("Reporte finalizado.");

            logger.info("Payment report generated at: {}", reportFileName);
        } catch (Exception e) {
            logger.error("Failed to generate payment report for proposal {}: {}", proposal.getExtId(), e.getMessage());
        }
    }
}
