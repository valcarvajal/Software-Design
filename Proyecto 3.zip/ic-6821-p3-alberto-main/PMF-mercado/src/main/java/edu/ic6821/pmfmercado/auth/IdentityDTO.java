package edu.ic6821.pmfmercado.auth;

public record IdentityDTO(String username) {
}
