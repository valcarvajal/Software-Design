package edu.ic6821.pmfmercado.payment;

import edu.ic6821.pmfmercado.proposal.Proposal;
import edu.ic6821.pmfmercado.framework.model.BaseEntity;
import jakarta.persistence.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "payments")
public class Payment extends BaseEntity {

    @ManyToOne
    @JoinColumn(name = "proposal_id", nullable = false)
    private Proposal proposal;

    @Column(nullable = false)
    private BigDecimal amount;

    @Column(nullable = false)
    private BigDecimal interest;

    @Column(nullable = false)
    private LocalDateTime paymentDate;

    public Payment() {}

    public Payment(Proposal proposal, BigDecimal amount, BigDecimal interest, LocalDateTime paymentDate) {
        this.proposal = proposal;
        this.amount = amount;
        this.interest = interest;
        this.paymentDate = paymentDate;
    }

    public Proposal getProposal() {
        return proposal;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public BigDecimal getInterest() {
        return interest;
    }

    public LocalDateTime getPaymentDate() {
        return paymentDate;
    }
}
