package edu.ic6821.pmfmercado.proposal;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

public interface ProposalService {
    Optional<Proposal> create(String description, BigDecimal requestedAmount, int installments, String status, BigDecimal monthlyPayment, BigDecimal interestRate, BigDecimal amountPending, BigDecimal assignedRiskRating);
    Optional<Proposal> get(String extId);
    Optional<Proposal> publishProposal(String extId);
    Optional<Proposal> closeCreditOperation(String extId);
    List<Proposal> getPublishedProposals();
}