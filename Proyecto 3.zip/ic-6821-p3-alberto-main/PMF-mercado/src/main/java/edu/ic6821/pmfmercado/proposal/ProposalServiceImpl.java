package edu.ic6821.pmfmercado.proposal;

import org.springframework.stereotype.Service;
import edu.ic6821.pmfmercado.report.HistoricalReportService;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@Service
public class ProposalServiceImpl implements ProposalService {
    private final ProposalRepository proposalRepository;
    private final HistoricalReportService historicalReportService;

    public ProposalServiceImpl(ProposalRepository proposalRepository, HistoricalReportService historicalReportService) {
        this.proposalRepository = proposalRepository;
        this.historicalReportService = historicalReportService; 
    }

    @Override
    public Optional<Proposal> create(String description, BigDecimal requestedAmount, int installments, String status, BigDecimal monthlyPayment, BigDecimal interestRate, BigDecimal amountPending, BigDecimal assignedRiskRating){
        Proposal proposal = new Proposal(description, requestedAmount, installments, status, monthlyPayment, interestRate, amountPending, assignedRiskRating);
        proposalRepository.save(proposal);
        return Optional.of(proposal);
    }

    @Override
    public Optional<Proposal> get(String extId) {
        return proposalRepository.findByExtId(extId);
    }
    
    @Override 
public Optional<Proposal> publishProposal(String extId) {
    Optional<Proposal> proposalOpt = proposalRepository.findByExtId(extId);
    Proposal proposal = proposalOpt.get();
    if (!"ACCEPTED".equals(proposal.getStatus())) {
        throw new IllegalArgumentException("Proposal status should be 'ACCEPTED'");
    }
    proposal.setStatus("PUBLISHED");
    proposalRepository.save(proposal);
    return Optional.of(proposal);
}

    @Override
    public Optional<Proposal> closeCreditOperation(String extId) {
        Optional<Proposal> proposalOpt = proposalRepository.findByExtId(extId);
        Proposal proposal = proposalOpt.get();
        proposal.setStatus("CLOSED");
        proposalRepository.save(proposal);
        historicalReportService.create(
                proposal.getId(),
                proposal.getExtId(),
                proposal.getDescription(),
                proposal.getRequestedAmount(),
                proposal.getStatus()
        );
        
        return Optional.of(proposal);
    }

    @Override
    public List<Proposal> getPublishedProposals() {
        return proposalRepository.findByStatus("PUBLISHED");
    }
}
