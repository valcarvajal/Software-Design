package edu.ic6821.pmfmercado.proposal;

public record ProposalIdDTO(String extId) {
}
