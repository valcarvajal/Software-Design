package edu.ic6821.pmfmercado.auth;

public enum AuthStatus {
    AUTH_SUCCEEDED, AUTH_FAILED
}
