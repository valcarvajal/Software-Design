package edu.ic6821.pmfmercado.proposal;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/proposal")
public class ProposalController {

    private static final Logger logger = LoggerFactory.getLogger(ProposalController.class);
    private static final String CREATE_PROPOSAL_SUMMARY = "Create new proposal";
    private static final String PUBLISH_PROPOSAL_SUMMARY = "Publish proposal to lenders";
    private static final String CLOSE_CREDIT_SUMMARY = "Close credit operation and generate historical report";
    private static final String BEARER_AUTHENTICATION = "Bearer Authentication";

    @Autowired
    private ProposalService proposalService;

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    @Operation(summary = CREATE_PROPOSAL_SUMMARY)
    @SecurityRequirement(name = BEARER_AUTHENTICATION)
    public ProposalIdDTO create(@RequestBody ProposalDTO proposalDTO) {
        logger.info("Creating new proposal: " + proposalDTO.description());
        Optional<Proposal> optProposal = proposalService.create(
                proposalDTO.description(),
                proposalDTO.requestedAmount(),
                proposalDTO.installments(),
                proposalDTO.status(),
                proposalDTO.monthlyPayment(),
                proposalDTO.interestRate(), 
                proposalDTO.amountPending(),
                proposalDTO.assignedRiskRating()
        );
        return new ProposalIdDTO(optProposal.get().getExtId());
    }

    @PostMapping("/publish/{extId}")
    @ResponseStatus(HttpStatus.OK)
    @Operation(summary = PUBLISH_PROPOSAL_SUMMARY)
    @SecurityRequirement(name = BEARER_AUTHENTICATION)
    public ProposalIdDTO publish(@PathVariable String extId) {
        logger.info("Publishing proposal with extId: " + extId);
        proposalService.publishProposal(extId);
        return new ProposalIdDTO(extId);
    }
    @PostMapping("/close/{extId}")
    @ResponseStatus(HttpStatus.OK)
    @Operation(summary = CLOSE_CREDIT_SUMMARY)
    @SecurityRequirement(name = BEARER_AUTHENTICATION)
    public ProposalIdDTO closeCredit(@PathVariable String extId) {
        logger.info("Closing credit operation for proposal with extId: " + extId);
        proposalService.closeCreditOperation(extId);
        return new ProposalIdDTO(extId);
    }
    @GetMapping("/published")
    @Operation(summary = "List all published proposals")
    @SecurityRequirement(name = BEARER_AUTHENTICATION)
    public List<ProposalDTO> listPublishedProposals() {
        List<Proposal> publishedProposals = proposalService.getPublishedProposals();
        return publishedProposals.stream()
                .map(proposal -> new ProposalDTO(proposal.getDescription(), proposal.getRequestedAmount(),  proposal.getInstallments(), proposal.getStatus(), proposal.getMonthlyPayment(), proposal.getInterestRate(), proposal.getAmountPending(), proposal.getAssignedRiskRating()))
                .toList();
    }
    @GetMapping("/{extId}")
    @Operation(summary = "Get proposal by external ID")
    @SecurityRequirement(name = BEARER_AUTHENTICATION)
    public ProposalDTO get(@PathVariable String extId) {
        logger.info("Retrieving proposal with extId: " + extId);
        Proposal proposal = proposalService.get(extId).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
        return new ProposalDTO(proposal.getDescription(), proposal.getRequestedAmount(),  proposal.getInstallments(), proposal.getStatus(), proposal.getMonthlyPayment(), proposal.getInterestRate(), proposal.getAmountPending(), proposal.getAssignedRiskRating());
    }
}
