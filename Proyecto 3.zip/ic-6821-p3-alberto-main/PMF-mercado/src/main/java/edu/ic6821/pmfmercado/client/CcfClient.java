package edu.ic6821.pmfmercado.client;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.math.BigDecimal;

@Service
public class CcfClient {

    private static final String CCF_API_URL = "http://localhost:8082"; // URL base del módulo CCF
    private final RestTemplate restTemplate;

    public CcfClient(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public BigDecimal getRiskRating(String proposalId) {
        String url = CCF_API_URL + "/api/ccf/risk-rating/" + proposalId;
        return restTemplate.getForObject(url, BigDecimal.class);
    }
}
