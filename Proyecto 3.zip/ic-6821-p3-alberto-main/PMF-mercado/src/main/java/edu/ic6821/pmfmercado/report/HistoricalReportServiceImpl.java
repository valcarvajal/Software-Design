package edu.ic6821.pmfmercado.report;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.Optional;

@Service
public class HistoricalReportServiceImpl implements HistoricalReportService {

    @Autowired
    private HistoricalReportRepository historicalReportRepository;

    @Override
    public Optional<HistoricalReport> create(Long proposalId, String extId, String description, BigDecimal requestedAmount, String status) {
        HistoricalReport report = new HistoricalReport(proposalId, extId, description, requestedAmount, status);
        HistoricalReport savedReport = historicalReportRepository.save(report);
        return Optional.of(savedReport);
    }
}
