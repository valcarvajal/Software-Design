package edu.ic6821.pmfmercado.financingoffer;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FinancingOfferRepository extends JpaRepository<FinancingOffer, Long> {
}
