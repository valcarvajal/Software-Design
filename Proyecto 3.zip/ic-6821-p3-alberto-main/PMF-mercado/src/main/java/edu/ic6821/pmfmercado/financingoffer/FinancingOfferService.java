package edu.ic6821.pmfmercado.financingoffer;

import java.math.BigDecimal;
import java.util.Optional;

public interface FinancingOfferService {
    Optional<FinancingOffer> create(String proposalExtId, String lenderId, BigDecimal amountOffered);
}
