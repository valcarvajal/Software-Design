package edu.ic6821.pmfmercado.report;

import java.math.BigDecimal;
import java.util.Optional;

public interface HistoricalReportService {
    Optional<HistoricalReport> create(Long proposalId, String extId, String description, BigDecimal requestedAmount, String status);
}