package edu.ic6821.pmfmercado.financingoffer;

import java.math.BigDecimal;

public record FinancingOfferResponseDTO(String extId, BigDecimal amountPending) {
}
