ALTER TABLE proposals
ADD monthly_payment DECIMAL(19,2);

ALTER TABLE proposals
ADD interest_rate DECIMAL(5,2) NOT NULL;
