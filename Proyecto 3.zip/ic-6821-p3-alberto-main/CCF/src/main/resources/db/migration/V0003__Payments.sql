CREATE TABLE payments (
    id INT IDENTITY PRIMARY KEY,
    request_id VARCHAR(255) NOT NULL,
    amount DECIMAL(19, 2) NOT NULL,
    payer_contact VARCHAR(255) NOT NULL,
    ext_id VARCHAR(36) UNIQUE NOT NULL,
    created_on TIMESTAMP DEFAULT NOW,
    last_updated_on TIMESTAMP DEFAULT NOW
);
