package edu.ic6821.ccf.disbursements;

import edu.ic6821.ccf.framework.model.BaseEntity;
import jakarta.persistence.*;

import java.math.BigDecimal;

@Entity
@Table(name = "disbursements")
public class Disbursement extends BaseEntity {

    @Column(name = "request_id", nullable = false)
    private String requestId;

    @Column(name = "amount", nullable = false)
    private BigDecimal amount;

    @Column(name = "recipient_contact", nullable = false)
    private String recipientContact;

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getRecipientContact() {
        return recipientContact;
    }

    public void setRecipientContact(String recipientContact) {
        this.recipientContact = recipientContact;
    }

    @Override
    public String toString() {
        return "Disbursement{" +
                "requestId='" + requestId + '\'' +
                ", amount=" + amount +
                ", recipientContact='" + recipientContact + '\'' +
                "} " + super.toString();
    }
}
