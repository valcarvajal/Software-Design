package edu.ic6821.ccf.auth;

public enum AuthStatus {
    AUTH_SUCCEEDED, AUTH_FAILED
}
