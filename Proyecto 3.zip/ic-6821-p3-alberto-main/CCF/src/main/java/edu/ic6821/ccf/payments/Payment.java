package edu.ic6821.ccf.payments;

import edu.ic6821.ccf.framework.model.BaseEntity;
import jakarta.persistence.*;

import java.math.BigDecimal;

@Entity
@Table(name = "payments")
public class Payment extends BaseEntity {

    @Column(name = "request_id", nullable = false)
    private String requestId;

    @Column(name = "amount", nullable = false)
    private BigDecimal amount;

    @Column(name = "payer_contact", nullable = false)
    private String payerContact;

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getPayerContact() {
        return payerContact;
    }

    public void setPayerContact(String payerContact) {
        this.payerContact = payerContact;
    }

    @Override
    public String toString() {
        return "Payment{" +
                "requestId='" + requestId + '\'' +
                ", amount=" + amount +
                ", payerContact='" + payerContact + '\'' +
                "} " + super.toString();
    }
}