package edu.ic6821.ccf.receipts;

import java.math.BigDecimal;

public record ReceiptDTO(String requestId, BigDecimal amount, String contact, String type) {
    public ReceiptDTO(Receipt receipt) {
        this(receipt.getRequestId(), receipt.getAmount(), receipt.getContact(), receipt.getType());
    }
}