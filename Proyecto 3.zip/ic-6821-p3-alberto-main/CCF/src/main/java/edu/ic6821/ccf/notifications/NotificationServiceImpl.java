package edu.ic6821.ccf.notifications;

import org.springframework.stereotype.Service;

@Service
public class NotificationServiceImpl implements NotificationService {

    @Override
    public void sendNotification(String contact, String message) {
        System.out.println("Notificacion enviada a " + contact + ": " + message);
    }
}
