package edu.ic6821.ccf.disbursements;

import java.math.BigDecimal;

public record DisbursementDTO(String requestId, BigDecimal amount, String recipientContact) {
    public DisbursementDTO(Disbursement disbursement) {
        this(disbursement.getRequestId(), disbursement.getAmount(), disbursement.getRecipientContact());
    }
}
