package edu.ic6821.ccf.auth;

public record AuthDTO(AuthStatus status, String token) {
}
