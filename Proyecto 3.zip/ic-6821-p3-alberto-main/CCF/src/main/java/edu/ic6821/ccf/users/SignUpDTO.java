package edu.ic6821.ccf.users;

public record SignUpDTO(SignUpStatus status, String username, String extId) {
}
