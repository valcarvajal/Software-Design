package edu.ic6821.ccf.auth;

public record IdentityDTO(String username) {
}
