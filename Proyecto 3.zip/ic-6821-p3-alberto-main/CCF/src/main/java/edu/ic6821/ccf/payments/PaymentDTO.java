package edu.ic6821.ccf.payments;

import java.math.BigDecimal;

public record PaymentDTO(String requestId, BigDecimal amount, String payerContact) {
    public PaymentDTO(Payment payment) {
        this(payment.getRequestId(), payment.getAmount(), payment.getPayerContact());
    }
}
