package edu.ic6821.ccf.payments;

import java.math.BigDecimal;
import java.util.Optional;

public interface PaymentService {
    Optional<Payment> registerPayment(String requestId, BigDecimal amount, String payerContact);
}
