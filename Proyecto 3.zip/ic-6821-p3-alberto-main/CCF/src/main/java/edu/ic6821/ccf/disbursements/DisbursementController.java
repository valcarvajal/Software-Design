package edu.ic6821.ccf.disbursements;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.Optional;

@RestController
@RequestMapping("/api/ccf/disbursements")
public class DisbursementController {

    private static final Logger logger = LoggerFactory.getLogger(DisbursementController.class);

    @Autowired
    private DisbursementService disbursementService;

    @PostMapping("/")
    @Operation(summary = "Register disbursement")
    @SecurityRequirement(name = "Bearer Authentication")
    public DisbursementDTO registerDisbursement(@RequestBody DisbursementDTO disbursementDTO) {
        logger.info(String.format("[%s.registerDisbursement] Registering disbursement for request %s",
                this.getClass(), disbursementDTO.requestId()));

        try {
            Optional<Disbursement> optDisbursement = disbursementService.registerDisbursement(
                    disbursementDTO.requestId(), disbursementDTO.amount(), disbursementDTO.recipientContact());

            if (optDisbursement.isEmpty()) {
                throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Disbursement registration failed");
            }

            return new DisbursementDTO(optDisbursement.get());
        } catch (Exception e) {
            logger.error(String.format("[%s.registerDisbursement] Unexpected error %s: %s",
                    this.getClass(), e.getClass().getSimpleName(), e.getMessage()), e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unexpected error occurred", e);
        }
    }
}
