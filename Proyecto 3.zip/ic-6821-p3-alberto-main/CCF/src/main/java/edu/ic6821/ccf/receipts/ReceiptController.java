package edu.ic6821.ccf.receipts;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.Optional;

@RestController
@RequestMapping("/api/ccf/receipts")
public class ReceiptController {

    private static final Logger logger = LoggerFactory.getLogger(ReceiptController.class);

    @Autowired
    private ReceiptService receiptService;

    @PostMapping("/")
    @Operation(summary = "Register receipt")
    @SecurityRequirement(name = "Bearer Authentication")
    public ReceiptDTO registerReceipt(@RequestBody ReceiptDTO receiptDTO) {
        logger.info(String.format("[%s.registerReceipt] Registering receipt for request %s",
                this.getClass(), receiptDTO.requestId()));

        try {
            Optional<Receipt> optReceipt = receiptService.registerReceipt(
                    receiptDTO.requestId(), receiptDTO.amount(), receiptDTO.contact(), receiptDTO.type());

            if (optReceipt.isEmpty()) {
                throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Receipt registration failed");
            }

            return new ReceiptDTO(optReceipt.get());
        } catch (Exception e) {
            logger.error(String.format("[%s.registerReceipt] Unexpected error %s: %s",
                    this.getClass(), e.getClass().getSimpleName(), e.getMessage()), e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unexpected error occurred", e);
        }
    }
}
