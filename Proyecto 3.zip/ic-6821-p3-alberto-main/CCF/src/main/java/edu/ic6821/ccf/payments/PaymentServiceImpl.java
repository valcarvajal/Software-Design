package edu.ic6821.ccf.payments;

import edu.ic6821.ccf.notifications.NotificationService;
import edu.ic6821.ccf.receipts.Receipt;
import edu.ic6821.ccf.receipts.ReceiptService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.math.BigDecimal;
import java.util.Optional;

@Service
public class PaymentServiceImpl implements PaymentService {

    @Autowired
    private PaymentRepository paymentRepository;

    @Autowired
    private ReceiptService receiptService;

    @Autowired
    private NotificationService notificationService;

    @Override
    public Optional<Payment> registerPayment(String requestId, BigDecimal amount, String payerContact) {
        Payment payment = new Payment();
        payment.setRequestId(requestId);
        payment.setAmount(amount);
        payment.setPayerContact(payerContact);
        paymentRepository.save(payment);

        Optional<Receipt> optReceipt = receiptService.registerReceipt(requestId, amount, payerContact, "PAYMENT");
        optReceipt.ifPresent(receipt -> notificationService.sendNotification(payerContact, "Recibo generado para el pago"));

        return Optional.of(payment);
    }
}
