package edu.ic6821.ccf.disbursements;

import edu.ic6821.ccf.notifications.NotificationService;
import edu.ic6821.ccf.receipts.Receipt;
import edu.ic6821.ccf.receipts.ReceiptService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.math.BigDecimal;
import java.util.Optional;

@Service
public class DisbursementServiceImpl implements DisbursementService {

    @Autowired
    private DisbursementRepository disbursementRepository;

    @Autowired
    private ReceiptService receiptService;

    @Autowired
    private NotificationService notificationService;

    @Override
    public Optional<Disbursement> registerDisbursement(String requestId, BigDecimal amount, String recipientContact) {
        Disbursement disbursement = new Disbursement();
        disbursement.setRequestId(requestId);
        disbursement.setAmount(amount);
        disbursement.setRecipientContact(recipientContact);
        disbursementRepository.save(disbursement);

        Optional<Receipt> optReceipt = receiptService.registerReceipt(requestId, amount, recipientContact, "DISBURSEMENT");
        optReceipt.ifPresent(receipt -> notificationService.sendNotification(recipientContact, "Recibo generado para el desembolso"));

        return Optional.of(disbursement);
    }
}
