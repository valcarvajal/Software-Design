package edu.ic6821.ccf.auth;

public record CredentialsDTO(String username, String password) {
}
