package edu.ic6821.ccf.payments;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.math.BigDecimal;
import java.util.Optional;

@RestController
@RequestMapping("/api/ccf/payments")
public class PaymentController {

    private static final Logger logger = LoggerFactory.getLogger(PaymentController.class);

    @Autowired
    private PaymentService paymentService;

    @PostMapping("/")
    @Operation(summary = "Register payment")
    @SecurityRequirement(name = "Bearer Authentication")
    public PaymentDTO registerPayment(@RequestBody PaymentDTO paymentDTO) {
        logger.info(String.format("[%s.registerPayment] Registering payment for request %s",
                this.getClass(), paymentDTO.requestId()));

        try {
            Optional<Payment> optPayment = paymentService.registerPayment(
                    paymentDTO.requestId(), paymentDTO.amount(), paymentDTO.payerContact());

            if (optPayment.isEmpty()) {
                throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Payment registration failed");
            }

            return new PaymentDTO(optPayment.get());
        } catch (Exception e) {
            logger.error(String.format("[%s.registerPayment] Unexpected error %s: %s",
                    this.getClass(), e.getClass().getSimpleName(), e.getMessage()), e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unexpected error occurred", e);
        }
    }
}
