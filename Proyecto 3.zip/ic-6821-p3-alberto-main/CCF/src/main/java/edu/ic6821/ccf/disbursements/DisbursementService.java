package edu.ic6821.ccf.disbursements;

import java.math.BigDecimal;
import java.util.Optional;

public interface DisbursementService {
    Optional<Disbursement> registerDisbursement(String requestId, BigDecimal amount, String recipientContact);
}
