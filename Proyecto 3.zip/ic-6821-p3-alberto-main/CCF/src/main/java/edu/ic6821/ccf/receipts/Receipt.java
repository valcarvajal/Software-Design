package edu.ic6821.ccf.receipts;

import edu.ic6821.ccf.framework.model.BaseEntity;
import jakarta.persistence.*;

import java.math.BigDecimal;

@Entity
@Table(name = "receipts")
public class Receipt extends BaseEntity {
    @Column(name = "request_id", nullable = false)
    private String requestId;

    @Column(name = "amount", nullable = false)
    private BigDecimal amount;

    @Column(name = "contact", nullable = false)
    private String contact;

    @Column(name = "type", nullable = false)
    private String type;

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return "Receipt{" +
                "requestId='" + requestId + '\'' +
                ", amount=" + amount +
                ", contact='" + contact + '\'' +
                ", type='" + type + '\'' +
                "} " + super.toString();
    }
}