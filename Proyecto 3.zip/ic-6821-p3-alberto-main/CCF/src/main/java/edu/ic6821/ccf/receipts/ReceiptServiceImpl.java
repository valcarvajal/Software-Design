package edu.ic6821.ccf.receipts;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.Optional;

@Service
public class ReceiptServiceImpl implements ReceiptService {

    @Autowired
    private ReceiptRepository receiptRepository;

    @Override
    public Optional<Receipt> registerReceipt(String requestId, BigDecimal amount, String contact, String type) {
        try {
            Receipt receipt = new Receipt();
            receipt.setRequestId(requestId);
            receipt.setAmount(amount);
            receipt.setContact(contact);
            receipt.setType(type);
            receiptRepository.save(receipt);
            return Optional.of(receipt);
        } catch (Exception e) {
            return Optional.empty();
        }
    }
}

