package edu.ic6821.ccf.notifications;

public interface NotificationService {
    void sendNotification(String contact, String message);
}
