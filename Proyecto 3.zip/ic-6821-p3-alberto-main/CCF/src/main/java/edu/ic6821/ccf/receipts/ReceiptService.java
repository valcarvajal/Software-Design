package edu.ic6821.ccf.receipts;

import java.math.BigDecimal;
import java.util.Optional;

public interface ReceiptService {
    Optional<Receipt> registerReceipt(String requestId, BigDecimal amount, String contact, String type);
}
