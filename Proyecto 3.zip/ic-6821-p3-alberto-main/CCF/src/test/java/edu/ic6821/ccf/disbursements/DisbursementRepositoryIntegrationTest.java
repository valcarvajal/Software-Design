package edu.ic6821.ccf.disbursements;

import edu.ic6821.ccf.disbursements.Disbursement;
import edu.ic6821.ccf.users.model.User;
import edu.ic6821.ccf.users.UserRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
public class DisbursementRepositoryIntegrationTest {

    @Autowired
    private DisbursementRepository disbursementRepository;

    @Autowired
    private UserRepository userRepository;

    @Test
    @Transactional
    public void saveAndFindById() {
        // given
        User user = new User("username", "password", "name", "email");
        User savedUser = userRepository.save(user);
        Disbursement newDisbursement = new Disbursement();
        newDisbursement.setRequestId("requestId123");
        newDisbursement.setAmount(BigDecimal.valueOf(150.00));
        newDisbursement.setRecipientContact(savedUser.getEmail());

        // when
        Disbursement savedDisbursement = disbursementRepository.save(newDisbursement);
        Optional<Disbursement> retrievedDisbursement = disbursementRepository.findById(savedDisbursement.getId());

        // then
        assertThat(retrievedDisbursement).isPresent();
        assertThat(retrievedDisbursement.get()).isEqualTo(savedDisbursement);
    }

    @Test
    @Transactional
    public void deleteDisbursement() {
        // given
        User user = new User("username", "password", "name", "email");
        User savedUser = userRepository.save(user);
        Disbursement disbursement = new Disbursement();
        disbursement.setRequestId("requestId124");
        disbursement.setAmount(BigDecimal.valueOf(200.00));
        disbursement.setRecipientContact(savedUser.getEmail());
        Disbursement savedDisbursement = disbursementRepository.save(disbursement);

        // when
        disbursementRepository.deleteById(savedDisbursement.getId());
        Optional<Disbursement> deletedDisbursement = disbursementRepository.findById(savedDisbursement.getId());

        // then
        assertThat(deletedDisbursement).isEmpty();
    }
}
