package edu.ic6821.ccf.payments;

import edu.ic6821.ccf.users.model.User;
import edu.ic6821.ccf.users.UserRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
public class PaymentRepositoryIntegrationTest {

    @Autowired
    private PaymentRepository paymentRepository;

    @Autowired
    private UserRepository userRepository;

    @Test
    @Transactional
    public void saveAndFindById() {
        // given
        User user = new User("username", "password", "name", "email");
        User savedUser = userRepository.save(user);
        Payment newPayment = new Payment();
        newPayment.setRequestId("requestId123");
        newPayment.setAmount(BigDecimal.valueOf(150.00));
        newPayment.setPayerContact(savedUser.getEmail());

        // when
        Payment savedPayment = paymentRepository.save(newPayment);
        Optional<Payment> retrievedPayment = paymentRepository.findById(savedPayment.getId());

        // then
        assertThat(retrievedPayment).isPresent();
        assertThat(retrievedPayment.get()).isEqualTo(savedPayment);
    }

    @Test
    @Transactional
    public void deletePayment() {
        // given
        User user = new User("username", "password", "name", "email");
        User savedUser = userRepository.save(user);
        Payment payment = new Payment();
        payment.setRequestId("requestId124");
        payment.setAmount(BigDecimal.valueOf(200.00));
        payment.setPayerContact(savedUser.getEmail());
        Payment savedPayment = paymentRepository.save(payment);

        // when
        paymentRepository.deleteById(savedPayment.getId());
        Optional<Payment> deletedPayment = paymentRepository.findById(savedPayment.getId());

        // then
        assertThat(deletedPayment).isEmpty();
    }
}
