package edu.ic6821.ccf.disbursements;

import com.fasterxml.jackson.databind.ObjectMapper;
import edu.ic6821.ccf.disbursements.DisbursementService;
import edu.ic6821.ccf.disbursements.Disbursement;
import edu.ic6821.ccf.disbursements.DisbursementDTO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import java.math.BigDecimal;
import java.util.Optional;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;

@SpringBootTest
class DisbursementControllerTest {

    @Mock
    private DisbursementService disbursementService;

    @InjectMocks
    private DisbursementController disbursementController;

    private MockMvc mockMvc;
    private ObjectMapper objectMapper = new ObjectMapper();

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(disbursementController).build();
    }

    @Test
    void testRegisterDisbursement_Success() throws Exception {
        // given
        String requestId = "request123";
        BigDecimal amount = new BigDecimal("100.0");
        String recipientContact = "recipient@example.com";

        Disbursement disbursement = new Disbursement();
        disbursement.setRequestId(requestId);
        disbursement.setAmount(amount);
        disbursement.setRecipientContact(recipientContact);

        DisbursementDTO disbursementDTO = new DisbursementDTO(requestId, amount, recipientContact);

        when(disbursementService.registerDisbursement(any(String.class), any(BigDecimal.class), any(String.class)))
                .thenReturn(Optional.of(disbursement));

        // when & then
        mockMvc.perform(post("/api/ccf/disbursements/")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(disbursementDTO)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.requestId").value(requestId))
                .andExpect(jsonPath("$.amount").value(amount.toPlainString()))
                .andExpect(jsonPath("$.recipientContact").value(recipientContact));
    }

    @Test
    void testRegisterDisbursement_ServerError() throws Exception {
        // given
        String requestId = "requestServerError";
        BigDecimal amount = new BigDecimal("300.00");
        String recipientContact = "error@example.com";

        DisbursementDTO disbursementDTO = new DisbursementDTO(requestId, amount, recipientContact);

        when(disbursementService.registerDisbursement(any(String.class), any(BigDecimal.class), any(String.class)))
                .thenThrow(new RuntimeException("Unexpected error"));

        // when & then
        mockMvc.perform(post("/api/ccf/disbursements/")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(disbursementDTO)))
                .andExpect(status().isInternalServerError());
    }
}
