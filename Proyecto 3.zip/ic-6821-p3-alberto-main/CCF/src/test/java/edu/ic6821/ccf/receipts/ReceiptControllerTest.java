package edu.ic6821.ccf.receipts;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.math.BigDecimal;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
class ReceiptControllerTest {

    @Mock
    private ReceiptService receiptService;

    @InjectMocks
    private ReceiptController receiptController;

    private MockMvc mockMvc;
    private ObjectMapper objectMapper = new ObjectMapper();

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(receiptController).build();
    }

    @Test
    void testRegisterReceipt_Success() throws Exception {
        // given
        String requestId = "request456";
        BigDecimal amount = new BigDecimal("150.0");
        String contact = "contact@example.com";
        String type = "DISBURSEMENT";

        Receipt receipt = new Receipt();
        receipt.setRequestId(requestId);
        receipt.setAmount(amount);
        receipt.setContact(contact);
        receipt.setType(type);

        ReceiptDTO receiptDTO = new ReceiptDTO(requestId, amount, contact, type);

        when(receiptService.registerReceipt(any(String.class), any(BigDecimal.class), any(String.class), any(String.class)))
                .thenReturn(Optional.of(receipt));

        // when & then
        mockMvc.perform(post("/api/ccf/receipts/")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(receiptDTO)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.requestId").value(requestId))
                .andExpect(jsonPath("$.amount").value(amount.toPlainString())) // Usar `toPlainString()` para precisión exacta
                .andExpect(jsonPath("$.contact").value(contact))
                .andExpect(jsonPath("$.type").value(type));
    }

    @Test
    void testRegisterReceipt_InternalServerError() throws Exception {
        // given
        String requestId = "request456";
        BigDecimal amount = new BigDecimal("150.00");
        String contact = "contact@example.com";
        String type = "DISBURSEMENT";

        ReceiptDTO receiptDTO = new ReceiptDTO(requestId, amount, contact, type);

        when(receiptService.registerReceipt(any(String.class), any(BigDecimal.class), any(String.class), any(String.class)))
                .thenThrow(new RuntimeException("Database connection error"));

        // when & then
        mockMvc.perform(post("/api/ccf/receipts/")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(receiptDTO)))
                .andExpect(status().isInternalServerError());
    }
}
