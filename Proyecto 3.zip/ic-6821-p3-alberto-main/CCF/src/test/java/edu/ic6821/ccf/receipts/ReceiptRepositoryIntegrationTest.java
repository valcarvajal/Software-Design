package edu.ic6821.ccf.receipts;

import edu.ic6821.ccf.users.model.User;
import edu.ic6821.ccf.users.UserRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
public class ReceiptRepositoryIntegrationTest {

    @Autowired
    private ReceiptRepository receiptRepository;

    @Autowired
    private UserRepository userRepository;

    @Test
    @Transactional
    public void saveAndFindById() {
        // given
        User user = new User("username", "password", "name", "email");
        User savedUser = userRepository.save(user);
        Receipt newReceipt = new Receipt();
        newReceipt.setRequestId("requestId123");
        newReceipt.setAmount(BigDecimal.valueOf(150.00));
        newReceipt.setContact(savedUser.getEmail());
        newReceipt.setType("type1");

        // when
        Receipt savedReceipt = receiptRepository.save(newReceipt);
        Optional<Receipt> retrievedReceipt = receiptRepository.findById(savedReceipt.getId());

        // then
        assertThat(retrievedReceipt).isPresent();
        assertThat(retrievedReceipt.get()).isEqualTo(savedReceipt);
    }

    @Test
    @Transactional
    public void deleteReceipt() {
        // given
        User user = new User("username", "password", "name", "email");
        User savedUser = userRepository.save(user);
        Receipt receipt = new Receipt();
        receipt.setRequestId("requestId124");
        receipt.setAmount(BigDecimal.valueOf(200.00));
        receipt.setContact(savedUser.getEmail());
        receipt.setType("type2");
        Receipt savedReceipt = receiptRepository.save(receipt);

        // when
        receiptRepository.deleteById(savedReceipt.getId());
        Optional<Receipt> deletedReceipt = receiptRepository.findById(savedReceipt.getId());

        // then
        assertThat(deletedReceipt).isEmpty();
    }
}
