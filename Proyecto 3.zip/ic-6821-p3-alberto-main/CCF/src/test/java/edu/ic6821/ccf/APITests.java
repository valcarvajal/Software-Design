package edu.ic6821.ccf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class APITests {

	@Test
	void contextLoads() {
	}

}
