package edu.ic6821.ccf.payments;

import edu.ic6821.ccf.notifications.NotificationService;
import edu.ic6821.ccf.receipts.Receipt;
import edu.ic6821.ccf.receipts.ReceiptService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import java.math.BigDecimal;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class PaymentServiceImplTest {

    @InjectMocks
    private PaymentServiceImpl paymentService;

    @Mock
    private PaymentRepository paymentRepository;

    @Mock
    private ReceiptService receiptService;

    @Mock
    private NotificationService notificationService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testRegisterPayment_PaymentCreationSuccess() {
        // given
        String requestId = "testRequestId";
        BigDecimal amount = BigDecimal.valueOf(150);
        String payerContact = "testPayer";

        Payment payment = new Payment();
        payment.setRequestId(requestId);
        payment.setAmount(amount);
        payment.setPayerContact(payerContact);

        Receipt receipt = new Receipt();

        when(paymentRepository.save(any(Payment.class))).thenReturn(payment);
        when(receiptService.registerReceipt(requestId, amount, payerContact, "PAYMENT")).thenReturn(Optional.of(receipt));

        // when
        Optional<Payment> actual = paymentService.registerPayment(requestId, amount, payerContact);

        // then
        assertTrue(actual.isPresent());
        assertEquals(requestId, actual.get().getRequestId());
        assertEquals(amount, actual.get().getAmount());
        verify(paymentRepository).save(any(Payment.class));
        verify(receiptService).registerReceipt(requestId, amount, payerContact, "PAYMENT");
        verify(notificationService).sendNotification(payerContact, "Recibo generado para el pago");
    }

    @Test
    void testRegisterPayment_ReceiptNotGenerated() {
        // given
        String requestId = "testRequestId";
        BigDecimal amount = BigDecimal.valueOf(150);
        String payerContact = "testPayer";

        Payment payment = new Payment();
        payment.setRequestId(requestId);
        payment.setAmount(amount);
        payment.setPayerContact(payerContact);

        when(paymentRepository.save(any(Payment.class))).thenReturn(payment);
        when(receiptService.registerReceipt(requestId, amount, payerContact, "PAYMENT")).thenReturn(Optional.empty());

        // when
        Optional<Payment> actual = paymentService.registerPayment(requestId, amount, payerContact);

        // then
        assertTrue(actual.isPresent());
        assertEquals(requestId, actual.get().getRequestId());
        verify(paymentRepository).save(any(Payment.class));
        verify(receiptService).registerReceipt(requestId, amount, payerContact, "PAYMENT");
        verify(notificationService, never()).sendNotification(anyString(), anyString());
    }
}
