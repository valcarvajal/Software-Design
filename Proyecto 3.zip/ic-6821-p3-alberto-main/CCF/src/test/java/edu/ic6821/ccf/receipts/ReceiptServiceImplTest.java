package edu.ic6821.ccf.receipts;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.math.BigDecimal;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class ReceiptServiceImplTest {

    @InjectMocks
    private ReceiptServiceImpl receiptService;

    @Mock
    private ReceiptRepository receiptRepository;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testRegisterReceipt_ReceiptCreationSuccess() {
        // given
        String requestId = "testRequestId";
        BigDecimal amount = BigDecimal.valueOf(200);
        String contact = "testContact";
        String type = "DISBURSEMENT";

        Receipt receipt = new Receipt();
        receipt.setRequestId(requestId);
        receipt.setAmount(amount);
        receipt.setContact(contact);
        receipt.setType(type);

        when(receiptRepository.save(any(Receipt.class))).thenReturn(receipt);

        // when
        Optional<Receipt> actual = receiptService.registerReceipt(requestId, amount, contact, type);

        // then
        assertTrue(actual.isPresent());
        assertEquals(requestId, actual.get().getRequestId());
        assertEquals(amount, actual.get().getAmount());
        assertEquals(contact, actual.get().getContact());
        assertEquals(type, actual.get().getType());
        verify(receiptRepository).save(any(Receipt.class));
    }

    @Test
    void testRegisterReceipt_RepositorySaveFails_ShouldReturnEmpty() {
        // given
        String requestId = "testRequestId";
        BigDecimal amount = BigDecimal.valueOf(200);
        String contact = "testContact";
        String type = "DISBURSEMENT";

        when(receiptRepository.save(any(Receipt.class))).thenThrow(new RuntimeException("Save failed"));

        // when
        Optional<Receipt> actual = receiptService.registerReceipt(requestId, amount, contact, type);

        // then
        assertTrue(actual.isEmpty());
        verify(receiptRepository).save(any(Receipt.class));
    }
}
