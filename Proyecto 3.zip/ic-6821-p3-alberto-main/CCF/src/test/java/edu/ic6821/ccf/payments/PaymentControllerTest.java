package edu.ic6821.ccf.payments;

import com.fasterxml.jackson.databind.ObjectMapper;
import edu.ic6821.ccf.payments.Payment;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.math.BigDecimal;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
class PaymentControllerTest {

    @Mock
    private PaymentService paymentService;

    @InjectMocks
    private PaymentController paymentController;

    private MockMvc mockMvc;
    private ObjectMapper objectMapper = new ObjectMapper();

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(paymentController).build();
    }

    @Test
    void testRegisterPayment_Success() throws Exception {
        // given
        String requestId = "request123";
        BigDecimal amount = new BigDecimal("100.0");
        String payerContact = "payer@example.com";

        Payment payment = new Payment();
        payment.setRequestId(requestId);
        payment.setAmount(amount);
        payment.setPayerContact(payerContact);

        PaymentDTO paymentDTO = new PaymentDTO(requestId, amount, payerContact);

        when(paymentService.registerPayment(any(String.class), any(BigDecimal.class), any(String.class)))
                .thenReturn(Optional.of(payment));

        // when & then
        mockMvc.perform(post("/api/ccf/payments/")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(paymentDTO)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.requestId").value(requestId))
                .andExpect(jsonPath("$.amount").value(amount.toPlainString()))
                .andExpect(jsonPath("$.payerContact").value(payerContact));
    }

    @Test
    void testRegisterPayment_InternalServerError() throws Exception {
        // given
        String requestId = "request123";
        BigDecimal amount = new BigDecimal("100.0");
        String payerContact = "payer@example.com";

        PaymentDTO paymentDTO = new PaymentDTO(requestId, amount, payerContact);

        when(paymentService.registerPayment(any(String.class), any(BigDecimal.class), any(String.class)))
                .thenThrow(new RuntimeException("Database connection error"));

        // when & then
        mockMvc.perform(post("/api/ccf/payments/")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(paymentDTO)))
                .andExpect(status().isInternalServerError());
    }
}
