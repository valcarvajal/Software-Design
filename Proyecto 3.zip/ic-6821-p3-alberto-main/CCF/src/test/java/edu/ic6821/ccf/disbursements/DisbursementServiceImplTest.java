package edu.ic6821.ccf.disbursements;

import edu.ic6821.ccf.notifications.NotificationService;
import edu.ic6821.ccf.receipts.Receipt;
import edu.ic6821.ccf.receipts.ReceiptService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import java.math.BigDecimal;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class DisbursementServiceImplTest {

    @InjectMocks
    private DisbursementServiceImpl disbursementService;

    @Mock
    private DisbursementRepository disbursementRepository;

    @Mock
    private ReceiptService receiptService;

    @Mock
    private NotificationService notificationService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testRegisterDisbursement_DisbursementCreationSuccess() {
        // given
        String requestId = "testRequestId";
        BigDecimal amount = BigDecimal.valueOf(100);
        String recipientContact = "testRecipient";

        Disbursement disbursement = new Disbursement();
        disbursement.setRequestId(requestId);
        disbursement.setAmount(amount);
        disbursement.setRecipientContact(recipientContact);

        Receipt receipt = new Receipt();

        when(disbursementRepository.save(any(Disbursement.class))).thenReturn(disbursement);
        when(receiptService.registerReceipt(requestId, amount, recipientContact, "DISBURSEMENT")).thenReturn(Optional.of(receipt));

        // when
        Optional<Disbursement> actual = disbursementService.registerDisbursement(requestId, amount, recipientContact);

        // then
        assertTrue(actual.isPresent());
        assertEquals(requestId, actual.get().getRequestId());
        assertEquals(amount, actual.get().getAmount());
        verify(disbursementRepository).save(any(Disbursement.class));
        verify(receiptService).registerReceipt(requestId, amount, recipientContact, "DISBURSEMENT");
        verify(notificationService).sendNotification(recipientContact, "Recibo generado para el desembolso");
    }

    @Test
    void testRegisterDisbursement_ReceiptNotGenerated() {
        // given
        String requestId = "testRequestId";
        BigDecimal amount = BigDecimal.valueOf(100);
        String recipientContact = "testRecipient";

        Disbursement disbursement = new Disbursement();
        disbursement.setRequestId(requestId);
        disbursement.setAmount(amount);
        disbursement.setRecipientContact(recipientContact);

        when(disbursementRepository.save(any(Disbursement.class))).thenReturn(disbursement);
        when(receiptService.registerReceipt(requestId, amount, recipientContact, "DISBURSEMENT")).thenReturn(Optional.empty());

        // when
        Optional<Disbursement> actual = disbursementService.registerDisbursement(requestId, amount, recipientContact);

        // then
        assertTrue(actual.isPresent());
        assertEquals(requestId, actual.get().getRequestId());
        verify(disbursementRepository).save(any(Disbursement.class));
        verify(receiptService).registerReceipt(requestId, amount, recipientContact, "DISBURSEMENT");
        verify(notificationService, never()).sendNotification(anyString(), anyString());
    }
}