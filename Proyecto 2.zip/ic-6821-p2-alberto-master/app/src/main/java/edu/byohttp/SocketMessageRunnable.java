package edu.byohttp;

import edu.byohttp.controller.HttpController;
import edu.byohttp.log.Log;
import edu.byohttp.methods.HttpResponse;
import edu.byohttp.parser.DefaultParser;
import edu.byohttp.parser.HttpRequest;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;

public final class SocketMessageRunnable implements Runnable {
    private final InputStream in;
    private final OutputStream out;
    private static final int BUFFER_SIZE = 2048;
    private final HttpController httpController;
    private final Log log;
    private static final int FINAL_INDEX = 3;
    private static final int INITIAL_INDEX = 0;
    private static final String WHITE_SPACE = " ";
    private static final String START = ": ";
    private static final String CRLF = "\r\n";
    private static final String SERVER_ERROR = "500 Internal Server Error";
    private static final String VERSION = "HTTP/1.1";
    private static final int LAST_BYTE = -1;
    private static final int OFFSET = 0;
    private static final String GET = "GET";
    private static final String HEAD = "HEAD";
    private static final String USERDIR = "user.dir";
    private static final String GET_PATH = "/app/src/main/resources";
    private static final String HEAD_PATH = "/app/src/main/resources/notfound.html";
    private static final String NOT_IMPLEMENTED_PATH = "/app/src/main/resources/notfound.html";

    public SocketMessageRunnable(final Socket socket, final HttpController httpController, final Log log)
            throws IOException {
        this.in = socket.getInputStream();
        this.out = socket.getOutputStream();
        this.httpController = httpController;
        this.log = log;
    }

    @Override
    public void run() {
        try {
            final String requestString = readResource(in);
            if (requestString.trim().isEmpty()) {
                return;
            }
            final HttpResponse httpResponse = httpController.execute(requestString);
            log.logRequest(requestString);
            log.logResponse(httpResponse);
            writeResponse(httpResponse, out);
            final Map<String, Consumer<HttpRequest>> statusActions = getStatusActions(requestString);

            final String statusCodePrefix = httpResponse.statusCode().substring(INITIAL_INDEX, FINAL_INDEX);

            if (statusActions.containsKey(statusCodePrefix)) {
                statusActions.get(statusCodePrefix).accept(new DefaultParser().parseRequest(requestString));
            }

            in.close();
            out.flush();
            out.close();
        } catch (Exception e) {
            final HttpResponse errorResponse = new HttpResponse(SERVER_ERROR, VERSION, new HashMap<>());
            log.logResponse(errorResponse);

            throw new RuntimeException(e);
        }
    }

    private Map<String, Consumer<HttpRequest>> getStatusActions(String requestString) {

        final Map<String, Consumer<HttpRequest>> actions = new HashMap<>();

        actions.put("200", request -> {
            if (requestString.startsWith(GET)) {
                final String resourcePath = System.getProperty(USERDIR) + GET_PATH + request.path();
                sendResource(resourcePath, out);
            }
        });

        actions.put("404", request -> {
            if (!requestString.startsWith(HEAD)) {
                final String resourcePath = System.getProperty(USERDIR) + HEAD_PATH;
                sendResource(resourcePath, out);
            }
        });

        actions.put("501", request -> {
            final String resourcePath = System.getProperty(USERDIR) + NOT_IMPLEMENTED_PATH;
            sendResource(resourcePath, out);
        });
        return actions;
    }

    private String readResource(InputStream inputStream) throws IOException {
        final StringBuilder requestBuilder = new StringBuilder();
        final byte[] buffer = new byte[BUFFER_SIZE];
        int bytesRead;
        while ((bytesRead = inputStream.read(buffer)) != LAST_BYTE) {
            requestBuilder.append(new String(buffer, OFFSET, bytesRead));
            if (bytesRead < BUFFER_SIZE) {
                break;
            }
        }
        return requestBuilder.toString();
    }

    private void sendResource(String resourcePath, OutputStream outputStream) {
        final Path path = Paths.get(resourcePath);
        try (InputStream inputStream = Files.newInputStream(path)) {
            final byte[] buffer = new byte[BUFFER_SIZE];
            int bytesRead;
            while ((bytesRead = inputStream.read(buffer)) != LAST_BYTE) {
                outputStream.write(buffer, OFFSET, bytesRead);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private void writeResponse(HttpResponse response, OutputStream outputStream) throws IOException {
        final String statusLine = response.version() + WHITE_SPACE + response.statusCode() + CRLF;
        outputStream.write(statusLine.getBytes());
        for (Map.Entry<String, String> header : response.headers().entrySet()) {
            outputStream.write((header.getKey() + START + header.getValue() + CRLF).getBytes());
        }
        outputStream.write(CRLF.getBytes());
        outputStream.flush();
    }

}
