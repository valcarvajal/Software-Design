package edu.byohttp.log;

import edu.byohttp.resourcehandler.ResourceHandler;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

public final class Utils implements HttpUtils {

    private static final String DATE_PATTERN = "EEE, dd MMM yyyy HH:mm:ss z";
    private static final String DATE_ID = "GMT-6";

    @Override
    public String getServerTime() {
        final SimpleDateFormat dateFormat = new SimpleDateFormat(DATE_PATTERN, Locale.US);
        dateFormat.setTimeZone(TimeZone.getTimeZone(DATE_ID));
        return dateFormat.format(new Date());
    }

    @Override
    public String getLastModified(String resourcePath, ResourceHandler resourceHandler) {
        final long lastModifiedTimestamp = resourceHandler.getLastModified(resourcePath);
        final Date lastModifiedDate = new Date(lastModifiedTimestamp);
        final SimpleDateFormat dateFormat = new SimpleDateFormat(DATE_PATTERN, Locale.US);
        dateFormat.setTimeZone(TimeZone.getTimeZone(DATE_ID));
        return dateFormat.format(lastModifiedDate);
    }
}
