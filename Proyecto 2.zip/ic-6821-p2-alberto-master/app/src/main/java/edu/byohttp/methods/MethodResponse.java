package edu.byohttp.methods;

import edu.byohttp.parser.HttpRequest;

public interface MethodResponse {
    HttpResponse execute(HttpRequest request);
}
