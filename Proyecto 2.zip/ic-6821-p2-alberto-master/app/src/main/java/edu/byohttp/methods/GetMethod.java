package edu.byohttp.methods;

import edu.byohttp.log.HttpUtils;
import edu.byohttp.parser.HttpRequest;
import edu.byohttp.resourcehandler.Resource;
import edu.byohttp.resourcehandler.ResourceHandler;

import java.util.HashMap;
import java.util.Map;

public final class GetMethod implements MethodResponse {

    private final ResourceHandler resourceHandler;
    private final HttpUtils httpUtils;

    public GetMethod(final ResourceHandler resourceHandler, final HttpUtils httpUtils) {
        this.resourceHandler = resourceHandler;
        this.httpUtils = httpUtils;
    }

    @Override
    public HttpResponse execute(HttpRequest request) {
        final String basePath = System.getProperty("user.dir") + "/app/src/main/resources";
        final String resourcePath = basePath + request.path();
        final Map<String, String> headers = new HashMap<>();

        if (!resourceHandler.resourceExists(resourcePath)) {
            headers.put("Server", "byohttp/0.0.1");
            headers.put("Date", httpUtils.getServerTime());
            headers.put("Connection", "close");

            return new HttpResponse("404 Not Found", "HTTP/1.1", headers);
        }

        final Resource resource = resourceHandler.getResource(resourcePath);

        headers.put("Server", "byohttp/0.0.1");
        headers.put("Date", httpUtils.getServerTime());
        headers.put("Content-Type", resource.mimeType());
        headers.put("Content-Length", String.valueOf(resource.size()));
        headers.put("Last-Modified", httpUtils.getLastModified(resource.path(), resourceHandler));
        headers.put("Connection", "keep-alive");
        headers.put("Accept-Ranges", "bytes");

        return new HttpResponse("200 OK", "HTTP/1.1", headers);
    }
}
