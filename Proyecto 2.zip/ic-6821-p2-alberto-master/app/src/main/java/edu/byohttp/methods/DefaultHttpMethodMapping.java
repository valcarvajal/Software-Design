package edu.byohttp.methods;

import edu.byohttp.parser.HttpMethod;
import edu.byohttp.parser.HttpRequest;

import java.util.Map;

public final class DefaultHttpMethodMapping implements HttpMethodMapping {

    private final Map<HttpMethod, MethodResponse> methods;

    public DefaultHttpMethodMapping(final Map<HttpMethod, MethodResponse> methods) {
        this.methods = methods;
    }

    @Override
    public HttpResponse handleRequest(HttpRequest request) {
        final HttpMethod method = request.method();
        final MethodResponse methodResponse = methods.get(method);
        return methodResponse.execute(request);
    }
}
