package edu.byohttp.parser;

public interface HttpParser {
    HttpRequest parseRequest(String request);
}
