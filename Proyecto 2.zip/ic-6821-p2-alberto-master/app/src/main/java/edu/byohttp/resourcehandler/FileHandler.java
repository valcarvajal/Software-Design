package edu.byohttp.resourcehandler;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public final class FileHandler implements ResourceHandler {

    private final Mime mimeHandler;
    private static final char DOT = '.';
    private static final String WHITE_SPACE = "";
    private static final int LAST_INDEX = -1;

    public FileHandler(final Mime mimeHandler) {
        this.mimeHandler = mimeHandler;
    }

    @Override
    public Resource getResource(String resourcePath) {
        try {
            final String mimeType = getMimeType(resourcePath);
            final long size = getResourceSize(resourcePath);
            return new Resource(resourcePath, mimeType, size);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public boolean resourceExists(String resourcePath) {
        final Path path = Paths.get(resourcePath);
        System.out.println(path);
        return Files.exists(path) && Files.isRegularFile(path);
    }

    @Override
    public long getResourceSize(String resourcePath) {
        final Path path = Paths.get(resourcePath);
        try {
            return Files.size(path);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public String getMimeType(String resourcePath) {
        final String extension = getResourceExtension(resourcePath);
        return mimeHandler.getMime(extension);
    }

    private String getResourceExtension(String resourcePath) {
        final int lastIndex = resourcePath.lastIndexOf(DOT);
        return (lastIndex == LAST_INDEX) ? WHITE_SPACE : resourcePath.substring(lastIndex);
    }

    @Override
    public long getLastModified(String resourcePath) {
        final Path path = Paths.get(resourcePath);
        try {
            return Files.getLastModifiedTime(path).toMillis();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
