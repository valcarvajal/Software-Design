package edu.byohttp.resourcehandler;

public record Resource(String path, String mimeType, long size) {
}
