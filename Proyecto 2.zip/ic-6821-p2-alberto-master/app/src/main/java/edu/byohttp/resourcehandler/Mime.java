package edu.byohttp.resourcehandler;

public interface Mime {
    String getMime(String path);
}
