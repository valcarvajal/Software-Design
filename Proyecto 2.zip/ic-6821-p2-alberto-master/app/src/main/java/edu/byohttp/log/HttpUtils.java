package edu.byohttp.log;

import edu.byohttp.resourcehandler.ResourceHandler;

public interface HttpUtils {
    String getServerTime();

    String getLastModified(String resourcePath, ResourceHandler resourceHandler);
}
