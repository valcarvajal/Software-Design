package edu.byohttp.methods;

import java.util.Map;

public record HttpResponse(String statusCode, String version, Map<String, String> headers) {
}
