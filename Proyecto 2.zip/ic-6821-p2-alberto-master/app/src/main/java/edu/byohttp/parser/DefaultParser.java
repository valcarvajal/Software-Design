package edu.byohttp.parser;

import java.util.HashMap;
import java.util.Map;

public final class DefaultParser implements HttpParser {

    private static final String CRLF = "\r\n";
    private static final String SPACE = " ";
    private static final String HEADER_SEPARATOR = ": ";
    private static final int INDEX_ZERO = 0;
    private static final int INDEX_ONE = 1;
    private static final int INDEX_TWO = 2;

    @Override
    public HttpRequest parseRequest(String request) {
        final String[] lines = request.split(CRLF);
        final String[] requestLine = parseRequestLine(lines[INDEX_ZERO]);
        final HttpMethod method = HttpMethod.valueOf(requestLine[INDEX_ZERO].toUpperCase().trim());
        final String path = requestLine[INDEX_ONE];
        final String version = requestLine[INDEX_TWO];

        final Map<String, String> headers = parseHeaders(lines);
        return new HttpRequest(method, path, version, headers);
    }

    private String[] parseRequestLine(String requestLine) {
        return requestLine.split(SPACE);
    }

    private Map<String, String> parseHeaders(String[] lines) {
        final Map<String, String> headers = new HashMap<>();

        for (int i = INDEX_ONE; i < lines.length; i++) {
            if (lines[i].isEmpty()) {
                break;
            }
            final String[] header = lines[i].split(HEADER_SEPARATOR, INDEX_TWO);
            headers.put(header[INDEX_ZERO], header[INDEX_ONE]);
        }

        return headers;
    }
}
