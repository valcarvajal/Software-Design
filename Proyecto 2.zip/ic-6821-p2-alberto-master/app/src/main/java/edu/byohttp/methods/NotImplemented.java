package edu.byohttp.methods;

import edu.byohttp.parser.HttpRequest;
import edu.byohttp.log.HttpUtils;

import java.util.HashMap;
import java.util.Map;

public final class NotImplemented implements MethodResponse {

    private final HttpUtils httpUtils;

    public NotImplemented(final HttpUtils httpUtils) {
        this.httpUtils = httpUtils;
    }

    @Override
    public HttpResponse execute(HttpRequest request) {
        final String serverVersion = "byohttp/0.0.1";
        final Map<String, String> headers = new HashMap<>();
        final String date = httpUtils.getServerTime();

        headers.put("Server", serverVersion);
        headers.put("Date", date);
        headers.put("Content-Type", "text/html");
        headers.put("Connection", "close");

        return new HttpResponse("501 Not Implemented", "HTTP/1.1", headers);
    }
}
