package edu.byohttp.controller;

import edu.byohttp.methods.HttpMethodMapping;
import edu.byohttp.methods.HttpResponse;
import edu.byohttp.parser.HttpParser;
import edu.byohttp.parser.HttpRequest;

public final class DefaultHttpController implements HttpController {
    private final HttpMethodMapping httpMethodMapping;
    private final HttpParser httpParser;

    public DefaultHttpController(final HttpMethodMapping httpMethodMapping, final HttpParser httpParser) {
        this.httpMethodMapping = httpMethodMapping;
        this.httpParser = httpParser;
    }

    @Override
    public HttpResponse execute(String requestMessage) {
        final HttpRequest request = httpParser.parseRequest(requestMessage);
        return httpMethodMapping.handleRequest(request);
    }
}
