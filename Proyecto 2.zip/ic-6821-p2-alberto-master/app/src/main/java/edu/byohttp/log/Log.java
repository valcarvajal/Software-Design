package edu.byohttp.log;

import edu.byohttp.methods.HttpResponse;

public interface Log {
    void logRequest(String requestMessage);

    void logResponse(HttpResponse errorMessage);
}
