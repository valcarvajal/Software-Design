package edu.byohttp.controller;

import edu.byohttp.methods.HttpResponse;

public interface HttpController {
    HttpResponse execute(String request);
}
