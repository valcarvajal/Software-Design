package edu.byohttp;

import edu.byohttp.controller.DefaultHttpController;
import edu.byohttp.log.DefaultLog;
import edu.byohttp.log.HttpUtils;
import edu.byohttp.log.Log;
import edu.byohttp.log.Utils;
import edu.byohttp.methods.DefaultHttpMethodMapping;
import edu.byohttp.methods.GetMethod;
import edu.byohttp.methods.HeadMethod;
import edu.byohttp.methods.MethodResponse;
import edu.byohttp.methods.NotImplemented;
import edu.byohttp.methods.HttpMethodMapping;
import edu.byohttp.parser.DefaultParser;
import edu.byohttp.parser.HttpParser;
import edu.byohttp.resourcehandler.DefaultMime;
import edu.byohttp.resourcehandler.FileHandler;
import edu.byohttp.resourcehandler.Mime;
import edu.byohttp.resourcehandler.ResourceHandler;
import edu.byohttp.controller.HttpController;
import edu.byohttp.parser.HttpMethod;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

public final class Config {

    private final File mimeTypesMapping;

    public Config(final File mimeTypesMapping) {
        this.mimeTypesMapping = mimeTypesMapping;
    }

    public HttpParser parser() {
        return new DefaultParser();
    }

    public HttpUtils httpUtils() {
        return new Utils();
    }

    public ResourceHandler resourceHandler() {
        return new FileHandler(mimeHandler());
    }

    public Mime mimeHandler() {
        return new DefaultMime(mimeTypesMapping);
    }

    public HttpMethodMapping httpMethodMapping() {
        final Map<HttpMethod, MethodResponse> methods = new HashMap<>();
        methods.put(HttpMethod.GET, new GetMethod(resourceHandler(), httpUtils()));
        methods.put(HttpMethod.HEAD, new HeadMethod(resourceHandler(), httpUtils()));
        methods.put(HttpMethod.PUT, new NotImplemented(httpUtils()));
        methods.put(HttpMethod.DELETE, new NotImplemented(httpUtils()));
        methods.put(HttpMethod.POST, new NotImplemented(httpUtils()));
        methods.put(HttpMethod.OPTIONS, new NotImplemented(httpUtils()));
        methods.put(HttpMethod.PATCH, new NotImplemented(httpUtils()));
        return new DefaultHttpMethodMapping(methods);
    }

    public Log log() {
        return new DefaultLog(httpUtils());
    }

    public HttpController httpController() {
        return new DefaultHttpController(httpMethodMapping(), parser());
    }
}
