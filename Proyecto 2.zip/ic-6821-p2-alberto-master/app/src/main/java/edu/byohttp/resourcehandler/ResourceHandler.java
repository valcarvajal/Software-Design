package edu.byohttp.resourcehandler;

public interface ResourceHandler {
    Resource getResource(String resourcePath);

    boolean resourceExists(String resourcePath);

    long getResourceSize(String resourcePath);

    String getMimeType(String resourcePath);

    long getLastModified(String resourcePath);
}
