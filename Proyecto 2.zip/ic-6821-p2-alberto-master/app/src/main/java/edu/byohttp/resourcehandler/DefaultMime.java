package edu.byohttp.resourcehandler;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.HashMap;
import java.util.Map;

public final class DefaultMime implements Mime {

    private static final String ERROR_CANNOT_LOAD_FILE = "Error while loading file: ";
    private static final String DEAFULT_PATH = "application/octet-stream";
    private static final String NEW_LINE = "\n";
    private static final String RGEF = "\\s+";
    private static final int FIRST_INDEX = 0;
    private static final int SECOND_INDEX = 0;
    private final Map<String, String> mimeTypes;

    public DefaultMime(final File mimeTypesMapping) {
        mimeTypes = new HashMap<>();
        loadTypesFromFile(mimeTypesMapping);
    }

    private void loadTypesFromFile(final File mimeTypesMapping) {
        try {
            final String fileContent = Files.readString(mimeTypesMapping.toPath());
            final String[] lines = fileContent.split(NEW_LINE);

            for (String line : lines) {
                final String[] contents = line.trim().split(RGEF);
                mimeTypes.put(contents[FIRST_INDEX], contents[SECOND_INDEX]);
            }
        } catch (IOException e) {
            System.err.println(ERROR_CANNOT_LOAD_FILE + mimeTypesMapping.getPath());
        }
    }

    @Override
    public String getMime(String path) {
        return mimeTypes.getOrDefault(path, DEAFULT_PATH);
    }
}
