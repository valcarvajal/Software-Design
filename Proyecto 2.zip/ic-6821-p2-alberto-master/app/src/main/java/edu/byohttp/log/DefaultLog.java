package edu.byohttp.log;

import edu.byohttp.methods.HttpResponse;

import java.util.ArrayList;
import java.util.List;

public final class DefaultLog implements Log {
    private final List<String> logEntries = new ArrayList<>();
    private final HttpUtils httpUtils;
    private static final String CRLF = "\n";

    public DefaultLog(final HttpUtils httpUtils) {
        this.httpUtils = httpUtils;
    }

    @Override
    public void logRequest(String requestMessage) {
        final String timestamp = httpUtils.getServerTime();
        final String entry = timestamp + CRLF + requestMessage;
        logEntries.add(entry);
        System.out.println(entry);
    }

    @Override
    public void logResponse(HttpResponse response) {
        final String timestamp = httpUtils.getServerTime();
        final String entry = timestamp + CRLF + response;
        logEntries.add(entry);
        System.out.println(entry);
    }
}
