package edu.byohttp.methods;

import edu.byohttp.parser.HttpRequest;

public interface HttpMethodMapping {
    HttpResponse handleRequest(HttpRequest request);
}
